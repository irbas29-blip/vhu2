 <!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8" />
        <title>Documentation - VHU2</title>
    </head> 

<!DOCTYPE html>
<html>  

<!--


ê
-->
<!--
Liste à améliorer en priorité:
-appli mobile
DARVA
-misiv
-global pre
-team viewer
-site ecommerce
-importer catalogue
-déchets dépollution
-Interface et logiciel 
-->


  




    <head>

        <meta charset="utf-8" />
         <link rel="stylesheet" href="style.css"/>
        <title>Qu'est-il possible de faire avec VHU2 ?</title>

    </head>
   
    <nav id="sommaire">        
    <div class="element_sommaire">
        
      

    <a href="https://www.cardiffvhu2.fr/" id="green"> <img style="width: 100% ;" src="logo vhu2.png"></a>
   
    <a style="display:flex;"href="https://www.youtube.com/playlist?list=PLcUB3Tm73B0EXawxHPw9PEJBR7PLWFJeE"><img src="cam.png" alt="e"><p><div style="font-size:13px;"><br>Retrouvez ici des tutoriels vidéos</div></p></a>

<h3><center>Environnement de VHU2</center></h3>

    <ol>
        <li style="margin-left:10px; color:white;"><a href="index.php">Présentation générale</a></li>
        <li style="margin-left:10px; color:white;"><a href="periph.php">Périphériques </a></li>
            <ul>
                <li  style="color:white;"><a href="douchette.php">Douchette </a></li>
                <li  style="color:white;"><a href="appli.php">Application mobile</a></li>
                <li  style="color:white;"><a href="imprimantes.php">Imprimantes</a></li>
            </ul>
        <li style="margin-left:10px;color:white;"><a href="interfaces.php">Interfaces</a></li>
            <ul>
                <li style="color:white;"><a  href="aaa.php">3A </a></li>
                <li style="color:white;"><a  href="darva.php">DARVA</a></li>
                <li style="color:white;"><a  href="misiv.php">MiSIV-TMS (SIV)</a></li>
                <li style="color:white;"><a  href="globalpre.php">Global PRE</a></li>
                <li style="color:white;"><a  href="teamviewer.php">TeamViewer</a></li>
                <li style="color:white;"><a  href="ecommerce.php">Sites e-commerce </a></li>
            </ul>
        <li style="margin-left:10px;color:white;"><a href="rech.tri.php">Recherche-tri</a></li>
    </ol>
<br>

<h3><center>Dossiers (véhicules)</center></h3>

    <ol>
        <li style="margin-left:10px;color:white;"><a href="ajouterparc.php">Ajouter un véhicule</a></li>
        <li style="margin-left:10px;color:white;"><a href="livrepolice.php">Livre de police</a></li>
        <li style="margin-left:10px;color:white;"><a href="gestionparc.php">Gestion du parc </a></li>
        <li style="margin-left:10px;color:white;"><a href="enlevements.php">Gérer les enlèvements</a></li>
        <li style="margin-left:10px;color:white;"><a href="offres.php">Gérer les appels d'offres</a></li>
        <li style="margin-left:10px;color:white;"><a href="lots.php">Gestion par lots</a></li>
            <ul>
                <li  style="color:white;"><a href="ajouterlot.php">Ajouter un lot</a></li>
                <li  style="color:white;"><a href="retirerlot.php">Retirer un lot</a></li>
            </ul>
    </ol>
<br>

<h3><center>Articles (pièces)</center></h3>

    <ol>
        <li style="margin-left:10px;color:white;"><a href="ajoutpiece.php">Ajouter des pièces</a></li>
        <li style="margin-left:10px;color:white;"><a href="demontage.php">Fiches de démontage</a></li>
        <li style="margin-left:10px;color:white;"><a href="catalogue.php">Visualiser le catalogue</a></li>
        <li style="margin-left:10px;color:white;"><a href="migrations.php">Visualiser les migrations</a></li>
        <li style="margin-left:10px;color:white;"><a href="importcatalogue.php">Importer un catalogue</a></li>
    </ol>
<br>

<h3><center>Gestion financière</center></h3>

    <ol>
        <li style="margin-left:10px;color:white;"><a href="facturation.php">Outil facturation</a></li>
        <li style="margin-left:10px;color:white;"><a href="facturevehicule.php">Facturation de véhicule</a></li>
        <li style="margin-left:10px;color:white;"><a href="proformas.php">Proformas et documents</a></li>
        <li style="margin-left:10px;color:white;"><a href="bl.php">Bons de livraison</a></li>
        <li style="margin-left:10px;color:white;"><a href="comptabilite.php">Interface comptable</a></li>
        <li style="margin-left:10px;color:white;"><a href="journal.php">Journal de vente</a></li>
        <li style="margin-left:10px;color:white;"><a href="inventaire.php">Inventaire de caisse</a></li>
    </ol>   
<br>

<h3><center>Dépollution</center></h3>

    <ol>
        <li style="margin-left:10px;color:white;"><a href="contenants.php">Gestion des contenants</a></li>
        <li style="margin-left:10px;color:white;"><a href="depollution.php">Dépollution de véhicules</a></li>
        <li style="margin-left:10px;color:white;"><a href="dechets.php">Gestion des déchets</a></li>
        <li style="margin-left:10px;color:white;"><a href="ademe.php">ADEME/SYDEREP</a></li>
    </ol>
<br>

<h3><center>Paramètres</center></h3>

    <ol>
        <li style="margin-left:10px;color:white;"><a href="paramlogiciel.php">Interface et logiciel</a></li>
        <li style="margin-left:10px;color:white;"><a href="intervenants.php">Intervenants et tiers</a></li>
        <li style="margin-left:10px;color:white;"><a href="infospersos.php">Vos informations</a></li>
        <li style="margin-left:10px;color:white;"><a href="deroulantes.php">Listes déroulantes</a></li>
    </ol>
<br>

<h3><center>Statistiques</center></h3>

    <ol>
        <li style="margin-left:10px;color:white;"><a href="stats.php">Vos statistiques</a></li>
    </ol>

<br>
<a href="https://www.vhu2.fr/#equipe"><center>Si vous souhaitez contacter l'équipe VHU2 :</center></a><br>

<a href="mailto:sav@vhu2.fr"><center><img style="width: 100% ;" src="sav.png"/></center></a><br>
<br>

       </div></nav></html>         

    <section>

<h1>Ajouter des pièces/articles</h1>

<iframe width="560" height="315" src="https://www.youtube.com/embed/ino1RuKrYco" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
<br>

<p>
    La gestion de vos pièces/articles est totalement gérée dans VHU2 tout comme celle des <a href="ajouterparc.php">VHU/dossiers</a>. <br>
    <br>
    La première étape sera bien sûr d'ajouter ces articles dans votre stock.<br>
    Pour ce faire, cliquez sur <u>Gestion des articles</u> depuis le menu, puis sur <u>Catalogue</u>.<br>
</p>

<img style="width: 30%;" src="ajouterarticle_menu"/> <img style="width: 30%;" src="ajouterarticle_sousmenu.png">
<br>
<br>

<p>
    Sur la nouvelle fenêtre qui est apparue, cliquez sur <u>Créer</u> en bas à droite.<br>
</p>

<img style="width: 80%;" src="ajouterarticle_créer">
<br>
<br>

<p>
    Sur cette page, rentrez bien sûr le plus d'informations possibles concernant l'article.<br>
    Il est fortement conseillé de rentrer également l'immatriculation de la voiture dont provient la pièce pour une meilleure tracabilité.<br>
</p>

<img style="width: 50%;" src="ajouterarticle_infos">
<br>
<br>

<p> 	
   	La partie inférieure est composée de plusieurs onglets, les deux premiers servent à renseigner vos prix d'achat et de revente et les TVA que vous désirez appliquer ainsi que les informations sur le fournisseur de l'article.<br>
</p>

<img style="width: 80%;" src="ajouterarticle_achatvente.png">
<br>
<br>

<p>
    Le troisième onglet sert à modifer directement votre stock, en écrivant une opération (comme +2) dans la case <u>Opération</u>. Ainsi, le stock changera (il sera incrémenté de 2 dans ce cas).<br>
</p>

<img style="width: 80%;" src="ajouterarticle_stock.png">
<br>
<br>

<p>
	L'onglet <u>Photos</u> permet simplement d'ajouter une photo en la cherchant directement dans vos fichiers ou depuis <a href="applismartphone.php">  l'application mobile</a>.<br>
    <br>
	Et finalement, l'onglet <u>Etiquette</u> permet d'imprimer un code-barre correspondant à la référence, que vous pourrez lire avec des <a href="douchette.php"> douchettes </a> qui sont compatibles avec notre logiciel.<br>
</p>

<img style="width: 80%;" src="ajouterarticle_photoétiq">
<br>
<br>

<p>
    Quand toutes les informations sont rentrées, cliquez sur <u>Enregistrer</u> en bas à droite. Vous pouvez maintenant retrouver cet article dans le <a href="catalogue.php"> catalogue</a>, très simplement en utilisant le système de <a href="rech.tri.php">recherche et de tri </a> du logiciel.<br>
    <br>
    Il est également intéressant de savoir que vous pouvez ajouter des articles à partir des <a href="demontage.php"> fiches de démontage</a> ou en faisant un <a href="importcatalogue.php"> import </a> depuis un catalogue externe.<br>
</p>

<br>

</section>
</html>