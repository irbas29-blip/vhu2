 <!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8" />
        <title>Documentation - VHU2</title>
    </head> 

<!DOCTYPE html>
<html>  

<!--


ê
-->
<!--
Liste à améliorer en priorité:
-appli mobile
DARVA
-misiv
-global pre
-team viewer
-site ecommerce
-importer catalogue
-déchets dépollution
-Interface et logiciel 
-->


  




    <head>

        <meta charset="utf-8" />
         <link rel="stylesheet" href="style.css"/>
        <title>Qu'est-il possible de faire avec VHU2 ?</title>

    </head>
   
    <nav id="sommaire">        
    <div class="element_sommaire">
        
      

    <a href="https://www.cardiffvhu2.fr/" id="green"> <img style="width: 100% ;" src="logo vhu2.png"></a>
   
    <a style="display:flex;"href="https://www.youtube.com/playlist?list=PLcUB3Tm73B0EXawxHPw9PEJBR7PLWFJeE"><img src="cam.png" alt="e"><p><div style="font-size:13px;"><br>Retrouvez ici des tutoriels vidéos</div></p></a>

<h3><center>Environnement de VHU2</center></h3>

    <ol>
        <li style="margin-left:10px; color:white;"><a href="index.php">Présentation générale</a></li>
        <li style="margin-left:10px; color:white;"><a href="periph.php">Périphériques </a></li>
            <ul>
                <li  style="color:white;"><a href="douchette.php">Douchette </a></li>
                <li  style="color:white;"><a href="appli.php">Application mobile</a></li>
                <li  style="color:white;"><a href="imprimantes.php">Imprimantes</a></li>
            </ul>
        <li style="margin-left:10px;color:white;"><a href="interfaces.php">Interfaces</a></li>
            <ul>
                <li style="color:white;"><a  href="aaa.php">3A </a></li>
                <li style="color:white;"><a  href="darva.php">DARVA</a></li>
                <li style="color:white;"><a  href="misiv.php">MiSIV-TMS (SIV)</a></li>
                <li style="color:white;"><a  href="globalpre.php">Global PRE</a></li>
                <li style="color:white;"><a  href="teamviewer.php">TeamViewer</a></li>
                <li style="color:white;"><a  href="ecommerce.php">Sites e-commerce </a></li>
            </ul>
        <li style="margin-left:10px;color:white;"><a href="rech.tri.php">Recherche-tri</a></li>
    </ol>
<br>

<h3><center>Dossiers (véhicules)</center></h3>

    <ol>
        <li style="margin-left:10px;color:white;"><a href="ajouterparc.php">Ajouter un véhicule</a></li>
        <li style="margin-left:10px;color:white;"><a href="livrepolice.php">Livre de police</a></li>
        <li style="margin-left:10px;color:white;"><a href="gestionparc.php">Gestion du parc </a></li>
        <li style="margin-left:10px;color:white;"><a href="enlevements.php">Gérer les enlèvements</a></li>
        <li style="margin-left:10px;color:white;"><a href="offres.php">Gérer les appels d'offres</a></li>
        <li style="margin-left:10px;color:white;"><a href="lots.php">Gestion par lots</a></li>
            <ul>
                <li  style="color:white;"><a href="ajouterlot.php">Ajouter un lot</a></li>
                <li  style="color:white;"><a href="retirerlot.php">Retirer un lot</a></li>
            </ul>
    </ol>
<br>

<h3><center>Articles (pièces)</center></h3>

    <ol>
        <li style="margin-left:10px;color:white;"><a href="ajoutpiece.php">Ajouter des pièces</a></li>
        <li style="margin-left:10px;color:white;"><a href="demontage.php">Fiches de démontage</a></li>
        <li style="margin-left:10px;color:white;"><a href="catalogue.php">Visualiser le catalogue</a></li>
        <li style="margin-left:10px;color:white;"><a href="migrations.php">Visualiser les migrations</a></li>
        <li style="margin-left:10px;color:white;"><a href="importcatalogue.php">Importer un catalogue</a></li>
    </ol>
<br>

<h3><center>Gestion financière</center></h3>

    <ol>
        <li style="margin-left:10px;color:white;"><a href="facturation.php">Outil facturation</a></li>
        <li style="margin-left:10px;color:white;"><a href="facturevehicule.php">Facturation de véhicule</a></li>
        <li style="margin-left:10px;color:white;"><a href="proformas.php">Proformas et documents</a></li>
        <li style="margin-left:10px;color:white;"><a href="bl.php">Bons de livraison</a></li>
        <li style="margin-left:10px;color:white;"><a href="comptabilite.php">Interface comptable</a></li>
        <li style="margin-left:10px;color:white;"><a href="journal.php">Journal de vente</a></li>
        <li style="margin-left:10px;color:white;"><a href="inventaire.php">Inventaire de caisse</a></li>
    </ol>   
<br>

<h3><center>Dépollution</center></h3>

    <ol>
        <li style="margin-left:10px;color:white;"><a href="contenants.php">Gestion des contenants</a></li>
        <li style="margin-left:10px;color:white;"><a href="depollution.php">Dépollution de véhicules</a></li>
        <li style="margin-left:10px;color:white;"><a href="dechets.php">Gestion des déchets</a></li>
        <li style="margin-left:10px;color:white;"><a href="ademe.php">ADEME/SYDEREP</a></li>
    </ol>
<br>

<h3><center>Paramètres</center></h3>

    <ol>
        <li style="margin-left:10px;color:white;"><a href="paramlogiciel.php">Interface et logiciel</a></li>
        <li style="margin-left:10px;color:white;"><a href="intervenants.php">Intervenants et tiers</a></li>
        <li style="margin-left:10px;color:white;"><a href="infospersos.php">Vos informations</a></li>
        <li style="margin-left:10px;color:white;"><a href="deroulantes.php">Listes déroulantes</a></li>
    </ol>
<br>

<h3><center>Statistiques</center></h3>

    <ol>
        <li style="margin-left:10px;color:white;"><a href="stats.php">Vos statistiques</a></li>
    </ol>

<br>
<a href="https://www.vhu2.fr/#equipe"><center>Si vous souhaitez contacter l'équipe VHU2 :</center></a><br>

<a href="mailto:sav@vhu2.fr"><center><img style="width: 100% ;" src="sav.png"/></center></a><br>
<br>

       </div></nav></html>         <body>

    <section>

   <h1>Global PRE</h1>

<p>
    Notre partenaire Global PRE vous offre plusieurs avantages en cas d'abonnement, comme par exemple des <a href="demontage.php"> fiches de démontage</a> adaptées à chaque type de véhicule pour toujours avoir une liste exhaustive des pièces récupérables sur un véhicule.<br>
    <br>
    Si cela vous intéresse, veuillez contacter notre SAV.<br>
</p>

<h2>Comment utiliser l'interface Global PRE ?</h2>

<p>
    Vous pouvez accéder à cette interface de fiches de démontage Global PRE de plusieurs façons :<br>
    <br>
    - via l'outil des fiches de démontage<br>
    <br>
    - via la fiche d'un véhicule.<br>
    <br>
</p>

<h3>Via l'outil des fiches de démontage</h3>

<p>
    Une fois votre abonnement à ce service effectué, vous pouvez accéder à l'interface Global PRE depuis votre logiciel VHU2 en suivant le chemin ci-dessous :<br>
    <br>
    Sur le menu principal, cliquez sur <u>Gestion des articles</u> puis sur l'onglet <u>Fiches de démontage</u>.<br>
</p>

<img style="width: 30%;" src="globalpre1.png" /> <img style="width: 30%;" src="globalpre2.png">
<br>
<br>

<p>
    Dans le menu des fiches de démontage, cliquez sur <u>Nouvelle Fiche de Démontage</u>. Cela vous affichera un message vous demandant si vous voulez créer une fiche de démontage avec les informations de Global PRE.<br>
</p>

<img style="width: 30%;" src="globalpre3.png" /> <img style="width: 30%;" src="globalpre4.png">
<br>
<br>

<p>
    Après avoir accepté le message précédent, vous arriverez sur une nouvelle fenêtre.<br>
    <br>
    Saisissez par exemple l'immatriculation du véhicule dont vous souhaitez obtenir la fiche de démontage puis cliquez sur le bouton <u>Obtenir le véhicule</u>. Les champs des informations concernant le véhicule se rempliront alors automatiquement.
</p>

<img style="width: 90%;" src="globalpre5.png">
<br>
<br>

<p>
    Une fenêtre apparaît pour vous demander de choisir la bonne version du véhicule.<br>
</p>

<img style="width: 90%;" src="globalpre6.png">
<br>
<br>

<p>
    Si vous ne savez pas, cliquez sur le bouton <u>Sélection à partir des équipements</u>. Vous pourrez alors identifier la version du véhicule à partir des équipements qu'il possède.<br>
</p>

<img style="width: 40%;" src="globalpre7.png">
<br>
<br>

<p>
    Après avoir sélectionné la bonne version du véhicule, un message vous demandera si vous souhaitez obtenir les pièces du véhicule. En acceptant, le tableau en fond se chargera avec l'ensemble des pièces du véhicule regroupés dans des familles.<br>
    <br>
    Naviguez dans l'arborescence pour trouver et sélectionner les pièces à démonter qui vous intéressent pour les rentrer au stock par la suite.<br>
</p>

<img style="width: 90%;" src="globalpre8.png">
<br>
<br>

<p>
    Pour effectuer le démontage des pièces du véhicule, voici un rappel des cases à cocher :<br> 
</p>

<img style="width: 30%;" src="demontage3.png">
<br>
<br>

<h3>Via la fiche d'un véhicule</h3>

<p>
    Vous pouvez gérer la fiche de démontage du véhicule de votre choix directement depuis la fiche de ce véhicule en procédant comme suit ou via le menu rapide des derniers dossiers :<br>
</p>

<img style="width: 30%;" src="globalpre9.png" /> <img style="width: 30%;" src="globalpre10.png">
<br>
<br>

<p>
    A partir de là, vous pouvez rechercher le véhicule avec son immatriculation.<br>
    <br>
    Vous arriverez ensuite sur la fiche du véhicule où vous pourrez retrouver les fiches de démontage dans l'onglet <u>Démontage</u>. 
</p>

<img style="width: 60%;" src="globalpre11.png">
<br>
<br>

<p>
    Cela vous amènera dans la fenêtre des fiches de démontage d'où vous pourrez créer une nouvelle fiche pour ce véhicule en cliquant sur le bouton en bas à gauche.<br>
</p>

<img style="width: 90%;" src="globalpre12.png">
<br>
<br>

<p>
    VHU 2 vous demandera ainsi si vous voulez créer cette fiche avec les données et les informations fournies par Global PRE.<br>
</p>

<img style="width: 30%;" src="globalpre13.png">
<br>
<br>

<p>
    Les données du véhicule sélectionné seront automatiquement enregistrées et vous n'avez plus qu'à cliquer sur le bouton <u>Obtenir le véhicule</u>.<br>
</p>

<img style="width: 100%;" src="globalpre14.png"> 
<br>
<br>

<p>
    Il ne vous reste plus qu'à sélectionner la bonne version du véhicule en vous aidant si besoin de la fenêtre des équipements embarqués.<br>
</p>

<img style="width: 40%;" src="globalpre15.png" >
<br> 
<br>

<img style="width: 50%;" src="globalpre7.png">
<br>
<br>

<p>
    Après avoir sélectionné la bonne version du véhicule, un message vous demandera si vous souhaitez obtenir les pièces du véhicule. En acceptant, le tableau en fond se chargera avec l'ensemble des pièces du véhicule regroupés dans des familles.<br>
    <br>
    Naviguez dans l'arborescence pour trouver et sélectionner les pièces à démonter qui vous intéressent pour les rentrer au stock par la suite.<br>
</p>

<img style="width: 90%;" src="globalpre8.png">
<br>
<br>

<p>
    Pour effectuer le démontage des pièces du véhicule, voici un rappel des cases à cocher :<br> 
</p>

<img style="width: 30%;" src="demontage3.png">
<br>
<br>

</section>
</body>
</html>