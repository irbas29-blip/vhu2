 <!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8" />
        <title>Documentation - VHU2</title>
    </head> 

<!DOCTYPE html>
<html>  

<!--


ê
-->
<!--
Liste à améliorer en priorité:
-appli mobile
DARVA
-misiv
-global pre
-team viewer
-site ecommerce
-importer catalogue
-déchets dépollution
-Interface et logiciel 
-->


  




    <head>

        <meta charset="utf-8" />
         <link rel="stylesheet" href="style.css"/>
        <title>Qu'est-il possible de faire avec VHU2 ?</title>

    </head>
   
    <nav id="sommaire">        
    <div class="element_sommaire">
        
      

    <a href="https://www.cardiffvhu2.fr/" id="green"> <img style="width: 100% ;" src="logo vhu2.png"></a>
   
    <a style="display:flex;"href="https://www.youtube.com/playlist?list=PLcUB3Tm73B0EXawxHPw9PEJBR7PLWFJeE"><img src="cam.png" alt="e"><p><div style="font-size:13px;"><br>Retrouvez ici des tutoriels vidéos</div></p></a>

<h3><center>Environnement de VHU2</center></h3>

    <ol>
        <li style="margin-left:10px; color:white;"><a href="index.php">Présentation générale</a></li>
        <li style="margin-left:10px; color:white;"><a href="periph.php">Périphériques </a></li>
            <ul>
                <li  style="color:white;"><a href="douchette.php">Douchette </a></li>
                <li  style="color:white;"><a href="appli.php">Application mobile</a></li>
                <li  style="color:white;"><a href="imprimantes.php">Imprimantes</a></li>
            </ul>
        <li style="margin-left:10px;color:white;"><a href="interfaces.php">Interfaces</a></li>
            <ul>
                <li style="color:white;"><a  href="aaa.php">3A </a></li>
                <li style="color:white;"><a  href="darva.php">DARVA</a></li>
                <li style="color:white;"><a  href="misiv.php">MiSIV-TMS (SIV)</a></li>
                <li style="color:white;"><a  href="globalpre.php">Global PRE</a></li>
                <li style="color:white;"><a  href="teamviewer.php">TeamViewer</a></li>
                <li style="color:white;"><a  href="ecommerce.php">Sites e-commerce </a></li>
            </ul>
        <li style="margin-left:10px;color:white;"><a href="rech.tri.php">Recherche-tri</a></li>
    </ol>
<br>

<h3><center>Dossiers (véhicules)</center></h3>

    <ol>
        <li style="margin-left:10px;color:white;"><a href="ajouterparc.php">Ajouter un véhicule</a></li>
        <li style="margin-left:10px;color:white;"><a href="livrepolice.php">Livre de police</a></li>
        <li style="margin-left:10px;color:white;"><a href="gestionparc.php">Gestion du parc </a></li>
        <li style="margin-left:10px;color:white;"><a href="enlevements.php">Gérer les enlèvements</a></li>
        <li style="margin-left:10px;color:white;"><a href="offres.php">Gérer les appels d'offres</a></li>
        <li style="margin-left:10px;color:white;"><a href="lots.php">Gestion par lots</a></li>
            <ul>
                <li  style="color:white;"><a href="ajouterlot.php">Ajouter un lot</a></li>
                <li  style="color:white;"><a href="retirerlot.php">Retirer un lot</a></li>
            </ul>
    </ol>
<br>

<h3><center>Articles (pièces)</center></h3>

    <ol>
        <li style="margin-left:10px;color:white;"><a href="ajoutpiece.php">Ajouter des pièces</a></li>
        <li style="margin-left:10px;color:white;"><a href="demontage.php">Fiches de démontage</a></li>
        <li style="margin-left:10px;color:white;"><a href="catalogue.php">Visualiser le catalogue</a></li>
        <li style="margin-left:10px;color:white;"><a href="migrations.php">Visualiser les migrations</a></li>
        <li style="margin-left:10px;color:white;"><a href="importcatalogue.php">Importer un catalogue</a></li>
    </ol>
<br>

<h3><center>Gestion financière</center></h3>

    <ol>
        <li style="margin-left:10px;color:white;"><a href="facturation.php">Outil facturation</a></li>
        <li style="margin-left:10px;color:white;"><a href="facturevehicule.php">Facturation de véhicule</a></li>
        <li style="margin-left:10px;color:white;"><a href="proformas.php">Proformas et documents</a></li>
        <li style="margin-left:10px;color:white;"><a href="bl.php">Bons de livraison</a></li>
        <li style="margin-left:10px;color:white;"><a href="comptabilite.php">Interface comptable</a></li>
        <li style="margin-left:10px;color:white;"><a href="journal.php">Journal de vente</a></li>
        <li style="margin-left:10px;color:white;"><a href="inventaire.php">Inventaire de caisse</a></li>
    </ol>   
<br>

<h3><center>Dépollution</center></h3>

    <ol>
        <li style="margin-left:10px;color:white;"><a href="contenants.php">Gestion des contenants</a></li>
        <li style="margin-left:10px;color:white;"><a href="depollution.php">Dépollution de véhicules</a></li>
        <li style="margin-left:10px;color:white;"><a href="dechets.php">Gestion des déchets</a></li>
        <li style="margin-left:10px;color:white;"><a href="ademe.php">ADEME/SYDEREP</a></li>
    </ol>
<br>

<h3><center>Paramètres</center></h3>

    <ol>
        <li style="margin-left:10px;color:white;"><a href="paramlogiciel.php">Interface et logiciel</a></li>
        <li style="margin-left:10px;color:white;"><a href="intervenants.php">Intervenants et tiers</a></li>
        <li style="margin-left:10px;color:white;"><a href="infospersos.php">Vos informations</a></li>
        <li style="margin-left:10px;color:white;"><a href="deroulantes.php">Listes déroulantes</a></li>
    </ol>
<br>

<h3><center>Statistiques</center></h3>

    <ol>
        <li style="margin-left:10px;color:white;"><a href="stats.php">Vos statistiques</a></li>
    </ol>

<br>
<a href="https://www.vhu2.fr/#equipe"><center>Si vous souhaitez contacter l'équipe VHU2 :</center></a><br>

<a href="mailto:sav@vhu2.fr"><center><img style="width: 100% ;" src="sav.png"/></center></a><br>
<br>

       </div></nav></html>       <body>  

    <section>

<h1>Les enlèvements</h1>

<p>
    Lorsque vous avez fait un <u>bon d'enlèvement (BE)</u> mais que le véhicule n'est pas encore au parc, vous pouvez tout de même en garder la trace.<br>
</p>

<img src="enlevement1.png">
<br>
<br>

<p>
    <a href="ajouterparc.php">Ajoutez un véhicule au parc</a>, et remplissez les cases relatives aux enlèvements. Indiquez également la date du BE et la date limite d'enlèvement. Lorsque vous avez rempli tout le nécessaire, quittez la page sans ajouter le véhicule au parc.<br>
    Cela a pour effet de cataloguer le véhicule comme "à enlever".<br>
    <br>
    Vous avez ensuite la possibilité de retrouver la liste de ces enlèvements en cliquant sur <u>Gestion des dossiers</u> depuis le menu principal puis sur <u>Liste des enlèvements</u>. Vous avez également la possibilité de transformer directement un <a href="offres.php">appel d'offre </a> en bon d'enlèvement.<br>
</p>

<img style="width: 30% ;" src="enlevement_menu.png"/> <img style="width: 30% ;" src="enlevement_sousmenu.png">
<br>
<br>

<img style="width: 95% ;" src="enlevement2.png">
<br>
<br>

<p>
    Les dossiers dont la date limite est dépassée apparaissent en rouge et ceux dont elle est proche en orange. Cliquez sur un dossier pour le modifier, et donc, pour l'ajouter au parc une fois l'enlèvement accompli. Il disparaitra alors de cette liste des enlèvements à réaliser.<br>
</p>

<br>

</section>
</body>
</html>