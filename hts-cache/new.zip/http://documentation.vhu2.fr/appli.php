<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8" />
        <title>Documentation - VHU2</title>
    </head> 

<!DOCTYPE html>
<html>  

<!--


ê
-->
<!--
Liste à améliorer en priorité:
-appli mobile
DARVA
-misiv
-global pre
-team viewer
-site ecommerce
-importer catalogue
-déchets dépollution
-Interface et logiciel 
-->


  




    <head>

        <meta charset="utf-8" />
         <link rel="stylesheet" href="style.css"/>
        <title>Qu'est-il possible de faire avec VHU2 ?</title>

    </head>
   
    <nav id="sommaire">        
    <div class="element_sommaire">
        
      

    <a href="https://www.cardiffvhu2.fr/" id="green"> <img style="width: 100% ;" src="logo vhu2.png"></a>
   
    <a style="display:flex;"href="https://www.youtube.com/playlist?list=PLcUB3Tm73B0EXawxHPw9PEJBR7PLWFJeE"><img src="cam.png" alt="e"><p><div style="font-size:13px;"><br>Retrouvez ici des tutoriels vidéos</div></p></a>

<h3><center>Environnement de VHU2</center></h3>

    <ol>
        <li style="margin-left:10px; color:white;"><a href="index.php">Présentation générale</a></li>
        <li style="margin-left:10px; color:white;"><a href="periph.php">Périphériques </a></li>
            <ul>
                <li  style="color:white;"><a href="douchette.php">Douchette </a></li>
                <li  style="color:white;"><a href="appli.php">Application mobile</a></li>
                <li  style="color:white;"><a href="imprimantes.php">Imprimantes</a></li>
            </ul>
        <li style="margin-left:10px;color:white;"><a href="interfaces.php">Interfaces</a></li>
            <ul>
                <li style="color:white;"><a  href="aaa.php">3A </a></li>
                <li style="color:white;"><a  href="darva.php">DARVA</a></li>
                <li style="color:white;"><a  href="misiv.php">MiSIV-TMS (SIV)</a></li>
                <li style="color:white;"><a  href="globalpre.php">Global PRE</a></li>
                <li style="color:white;"><a  href="teamviewer.php">TeamViewer</a></li>
                <li style="color:white;"><a  href="ecommerce.php">Sites e-commerce </a></li>
            </ul>
        <li style="margin-left:10px;color:white;"><a href="rech.tri.php">Recherche-tri</a></li>
    </ol>
<br>

<h3><center>Dossiers (véhicules)</center></h3>

    <ol>
        <li style="margin-left:10px;color:white;"><a href="ajouterparc.php">Ajouter un véhicule</a></li>
        <li style="margin-left:10px;color:white;"><a href="livrepolice.php">Livre de police</a></li>
        <li style="margin-left:10px;color:white;"><a href="gestionparc.php">Gestion du parc </a></li>
        <li style="margin-left:10px;color:white;"><a href="enlevements.php">Gérer les enlèvements</a></li>
        <li style="margin-left:10px;color:white;"><a href="offres.php">Gérer les appels d'offres</a></li>
        <li style="margin-left:10px;color:white;"><a href="lots.php">Gestion par lots</a></li>
            <ul>
                <li  style="color:white;"><a href="ajouterlot.php">Ajouter un lot</a></li>
                <li  style="color:white;"><a href="retirerlot.php">Retirer un lot</a></li>
            </ul>
    </ol>
<br>

<h3><center>Articles (pièces)</center></h3>

    <ol>
        <li style="margin-left:10px;color:white;"><a href="ajoutpiece.php">Ajouter des pièces</a></li>
        <li style="margin-left:10px;color:white;"><a href="demontage.php">Fiches de démontage</a></li>
        <li style="margin-left:10px;color:white;"><a href="catalogue.php">Visualiser le catalogue</a></li>
        <li style="margin-left:10px;color:white;"><a href="migrations.php">Visualiser les migrations</a></li>
        <li style="margin-left:10px;color:white;"><a href="importcatalogue.php">Importer un catalogue</a></li>
    </ol>
<br>

<h3><center>Gestion financière</center></h3>

    <ol>
        <li style="margin-left:10px;color:white;"><a href="facturation.php">Outil facturation</a></li>
        <li style="margin-left:10px;color:white;"><a href="facturevehicule.php">Facturation de véhicule</a></li>
        <li style="margin-left:10px;color:white;"><a href="proformas.php">Proformas et documents</a></li>
        <li style="margin-left:10px;color:white;"><a href="bl.php">Bons de livraison</a></li>
        <li style="margin-left:10px;color:white;"><a href="comptabilite.php">Interface comptable</a></li>
        <li style="margin-left:10px;color:white;"><a href="journal.php">Journal de vente</a></li>
        <li style="margin-left:10px;color:white;"><a href="inventaire.php">Inventaire de caisse</a></li>
    </ol>   
<br>

<h3><center>Dépollution</center></h3>

    <ol>
        <li style="margin-left:10px;color:white;"><a href="contenants.php">Gestion des contenants</a></li>
        <li style="margin-left:10px;color:white;"><a href="depollution.php">Dépollution de véhicules</a></li>
        <li style="margin-left:10px;color:white;"><a href="dechets.php">Gestion des déchets</a></li>
        <li style="margin-left:10px;color:white;"><a href="ademe.php">ADEME/SYDEREP</a></li>
    </ol>
<br>

<h3><center>Paramètres</center></h3>

    <ol>
        <li style="margin-left:10px;color:white;"><a href="paramlogiciel.php">Interface et logiciel</a></li>
        <li style="margin-left:10px;color:white;"><a href="intervenants.php">Intervenants et tiers</a></li>
        <li style="margin-left:10px;color:white;"><a href="infospersos.php">Vos informations</a></li>
        <li style="margin-left:10px;color:white;"><a href="deroulantes.php">Listes déroulantes</a></li>
    </ol>
<br>

<h3><center>Statistiques</center></h3>

    <ol>
        <li style="margin-left:10px;color:white;"><a href="stats.php">Vos statistiques</a></li>
    </ol>

<br>
<a href="https://www.vhu2.fr/#equipe"><center>Si vous souhaitez contacter l'équipe VHU2 :</center></a><br>

<a href="mailto:sav@vhu2.fr"><center><img style="width: 100% ;" src="sav.png"/></center></a><br>
<br>

       </div></nav></html>       <body>  

    <section>

<h1>Application mobile VHU2</h1>

<p>
    Vous avez la possibilité d'utiliser une application liée à votre logiciel VHU2 depuis votre téléphone (sous Android ou iOS).<br>
    <br>
    Celle-ci vous permet de prendre en photo des véhicules ou des pièces directement avec votre smartphone, afin qu'elles soient directement envoyées dans la base de données de votre logiciel et affectées aux véhicules ou pièces souhaités.<br>
    <br>
    L'application vous permet également de scanner des codes-barres présents sur des étiquettes reliées à des pièces de votre stock.<br>
    <br>
    L'installation devant être effectuée par notre équipe, si vous êtes intéressé par cette fonctionnalité, veuillez contacter notre SAV.<br>
    <br>
    Une fois en possession de cette application, vous pourrez prendre des photos de véhicules ou de pièces choisies. Vous pourrez ensuite exporter les photos que vous avez prises directement dans votre logiciel. <br>
</p>

<img style="width: 40% ;" src="appliphoto0.png">
<br>
<br>

<h2>Comment installer l'icône de l'application sur votre smartphone ?</h2>

<p>
    Pour retrouver votre application mobile VHU2 sur l'écran d'accueil de votre smartphone, voici comment procéder :<br>
</p>

    <h3>Sur un smartphone Android</h3>
<p>
    Lorsque vous êtes sur la page Internet reliée à l'application, rendez vous dans l'onglet des réglages de la page et appuyez sur le champ <u>Installer l'application</u> comme sur l'image ci-dessous :<br>
</p>

<img style="width: 20% ;" src="screen android.jpeg">
<br>

<p>
    Vous retrouverez ainsi l'application mobile sur votre écran d'accueil.<br>
    <br>
</p>

    <h3>Sur un iPhone</h3>

<p>
    En étant sur la page Internet reliée à l'application, rendez vous dans l'onglet des réglages de la page et appuyez sur le champ <u>Sur l'écran d'accueil</u> comme sur l'image ci-dessous :<br>
</p>

<img style="width: 20% ;" src="screen iphone.jpeg">
<br>

<p>
    Vous retrouverez ainsi l'application mobile sur votre écran d'accueil.<br>
    <br>
</p>

<h2>Prise de photos</h2>

<br>

    <h3>Depuis une saisie de référence ou immatriculation</h3>

        <p>
            Pour prendre des photos via votre application, saisissez une <u>référence de pièce ou une immatriculation</u> dans la barre de recherche et appuyez sur la loupe. Pensez bien à utiliser des tirets seulement s'ils sont présents dans la référence connue par VHU2.<br>
            <br>
        </p>

        <img style="width: 30% ;" src="appli_screen1.jpg">
        <br>
        <br>

        <p>
            Nous prendrons ici pour exemple une référence de pièce automobile désignant un démarreur.<br>        
        </p>

        <figure>  
        <img style="width: 30% ;" alt="" src="appli_screen_ref_piece1.jpg"/>          <img style="width: 30% ;" alt="" src="appli_screen_ref_piece2.jpg">
        <figcaption>Après avoir rentré la référence, appuyez sur la loupe.</figcaption><br>
        <figcaption>On vous demandera ensuite le type de la référence. Ici, il s'agit d'une pièce.</figcaption>
        </figure>
        <br>

        <p>
            Une fois sur la fiche de la pièce ou du véhicule, vous aurez la possibilité d'ajouter des photos.<br>
            <br>
        </p>

        <img style="width: 30% ;" src="appli_screen_ref_piece3.jpg">
        <br>

        <p>
            Appuyez sur une des icônes d'ajout de photos pour sélectionner une image que vous pouvez prendre via votre appareil photo ou via votre galerie.<br>
            <br>
            Sélectionnez les photos voulues et appuyez sur <u>Ok</u> pour procéder au téléchargement des photos.<br>
            <br>
            Vous avez maintenant l'aperçu des photos liées au véhicule ou à la pièce.
        </p>

        <img style="width: 30% ;" src="appli_screen_ref_piece4.jpg">
        <br>
        <br>

        <p>
            Voici maintenant un exemple avec un véhicule.<br>
        </p>
        <img style="width: 25% ;" src="appli_screen1.jpg"/> <img style="width: 25% ;" src="appli_screen2.jpg"/> <img style="width: 25% ;" src="appli_screen3.jpg"/>
        <br>
        <br>

    <h3>Depuis un scan de code-barre</h3>

        <p>
            Vous avez aussi la possibilité de scanner un code-barre en appuyant sur l'icône référente.<br>
        </p>
        
        <img style="width: 30% ;" src="appli_screen_scan_piece1.jpg">
        <br>

        <p>
            Cela va vous ouvir une fenêtre avec l'appareil photo. Vous n'avez plus qu'à passer le code-barre devant l'objectif qui le détectera.<br>
        </p>

        <img style="width: 30% ;" src="appli_screen_scan_piece2.jpg">
        <br>

        <p>
            La référence de la pièce sera ensuite automatiquement renseignée dans le champ de recherche. Appuyez sur la loupe pour accéder à sa fiche pour pouvoir lui attribuer des photos.<br>
        </p>

        <img style="width: 30% ;" src="appli_screen_scan_piece3.jpg"/> <img style="width: 30% ;" src="appli_screen_scan_piece4.jpg">
        <br>
        <br>

<h2>Export des photos vers votre logiciel VHU2</h2>

    <p>
        A partir de là, et en reprenant l'exemple du véhicule commencé plus haut, vous allez pouvoir récupérer ces photos associées à leur véhicule ou pièce sur votre logiciel VHU2.<br>
        <br>
        Sur votre poste utilisant VHU2, rendez vous dans <u>Outils</u> puis sur <u>Photos depuis l'application web</u>.<br>
    </p>

    <img style="width: 30% ;" src="appliweb1.png"/> <img style="width: 30%;" src="appliweb2.png">
    <br>
    <br>

    <p>
        Sur cette nouvelle fenêtre, cliquez sur <u>Affecter automatiquement les photos depuis le web</u>.<br>
        Après un moment de chargement, les photos que vous avez prises avec votre smartphone apparaissent selon le dossier (véhicule ou pièce) que vous aviez choisi sur l'application.<br>
        <br>
        <u>Important :</u> vérifiez bien que l'icône verte soit présente. Cela signifie que le processus a réussi.<br>
        En cliquant sur la photo, vous ouvrez un aperçu juste en dessous.
    </p>

    <img style="width: 90%;" src="appliweb3.png">
    <br>
    <br>

    <p>
    	Les photos sont affectées automatiquement au véhicule ou à la pièce initialement choisi et sont à retrouver dans les fiches individuelles du véhicule ou de la pièce.
    </p>

    <img style="width: 60%;" src="appliweb4.png"/> <img style="width: 40%;" src="appliweb5.png">
    <br>

</section>
</body>    
</html>