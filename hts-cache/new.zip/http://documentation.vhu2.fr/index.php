 <!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8" />
        <title>Documentation - VHU2</title>
    </head> 

<!DOCTYPE html>
<html>  

<!--


ê
-->
<!--
Liste à améliorer en priorité:
-appli mobile
DARVA
-misiv
-global pre
-team viewer
-site ecommerce
-importer catalogue
-déchets dépollution
-Interface et logiciel 
-->


  




    <head>

        <meta charset="utf-8" />
         <link rel="stylesheet" href="style.css"/>
        <title>Qu'est-il possible de faire avec VHU2 ?</title>

    </head>
   
    <nav id="sommaire">        
    <div class="element_sommaire">
        
      

    <a href="https://www.cardiffvhu2.fr/" id="green"> <img style="width: 100% ;" src="logo vhu2.png"></a>
   
    <a style="display:flex;"href="https://www.youtube.com/playlist?list=PLcUB3Tm73B0EXawxHPw9PEJBR7PLWFJeE"><img src="cam.png" alt="e"><p><div style="font-size:13px;"><br>Retrouvez ici des tutoriels vidéos</div></p></a>

<h3><center>Environnement de VHU2</center></h3>

    <ol>
        <li style="margin-left:10px; color:white;"><a href="index.php">Présentation générale</a></li>
        <li style="margin-left:10px; color:white;"><a href="periph.php">Périphériques </a></li>
            <ul>
                <li  style="color:white;"><a href="douchette.php">Douchette </a></li>
                <li  style="color:white;"><a href="appli.php">Application mobile</a></li>
                <li  style="color:white;"><a href="imprimantes.php">Imprimantes</a></li>
            </ul>
        <li style="margin-left:10px;color:white;"><a href="interfaces.php">Interfaces</a></li>
            <ul>
                <li style="color:white;"><a  href="aaa.php">3A </a></li>
                <li style="color:white;"><a  href="darva.php">DARVA</a></li>
                <li style="color:white;"><a  href="misiv.php">MiSIV-TMS (SIV)</a></li>
                <li style="color:white;"><a  href="globalpre.php">Global PRE</a></li>
                <li style="color:white;"><a  href="teamviewer.php">TeamViewer</a></li>
                <li style="color:white;"><a  href="ecommerce.php">Sites e-commerce </a></li>
            </ul>
        <li style="margin-left:10px;color:white;"><a href="rech.tri.php">Recherche-tri</a></li>
    </ol>
<br>

<h3><center>Dossiers (véhicules)</center></h3>

    <ol>
        <li style="margin-left:10px;color:white;"><a href="ajouterparc.php">Ajouter un véhicule</a></li>
        <li style="margin-left:10px;color:white;"><a href="livrepolice.php">Livre de police</a></li>
        <li style="margin-left:10px;color:white;"><a href="gestionparc.php">Gestion du parc </a></li>
        <li style="margin-left:10px;color:white;"><a href="enlevements.php">Gérer les enlèvements</a></li>
        <li style="margin-left:10px;color:white;"><a href="offres.php">Gérer les appels d'offres</a></li>
        <li style="margin-left:10px;color:white;"><a href="lots.php">Gestion par lots</a></li>
            <ul>
                <li  style="color:white;"><a href="ajouterlot.php">Ajouter un lot</a></li>
                <li  style="color:white;"><a href="retirerlot.php">Retirer un lot</a></li>
            </ul>
    </ol>
<br>

<h3><center>Articles (pièces)</center></h3>

    <ol>
        <li style="margin-left:10px;color:white;"><a href="ajoutpiece.php">Ajouter des pièces</a></li>
        <li style="margin-left:10px;color:white;"><a href="demontage.php">Fiches de démontage</a></li>
        <li style="margin-left:10px;color:white;"><a href="catalogue.php">Visualiser le catalogue</a></li>
        <li style="margin-left:10px;color:white;"><a href="migrations.php">Visualiser les migrations</a></li>
        <li style="margin-left:10px;color:white;"><a href="importcatalogue.php">Importer un catalogue</a></li>
    </ol>
<br>

<h3><center>Gestion financière</center></h3>

    <ol>
        <li style="margin-left:10px;color:white;"><a href="facturation.php">Outil facturation</a></li>
        <li style="margin-left:10px;color:white;"><a href="facturevehicule.php">Facturation de véhicule</a></li>
        <li style="margin-left:10px;color:white;"><a href="proformas.php">Proformas et documents</a></li>
        <li style="margin-left:10px;color:white;"><a href="bl.php">Bons de livraison</a></li>
        <li style="margin-left:10px;color:white;"><a href="comptabilite.php">Interface comptable</a></li>
        <li style="margin-left:10px;color:white;"><a href="journal.php">Journal de vente</a></li>
        <li style="margin-left:10px;color:white;"><a href="inventaire.php">Inventaire de caisse</a></li>
    </ol>   
<br>

<h3><center>Dépollution</center></h3>

    <ol>
        <li style="margin-left:10px;color:white;"><a href="contenants.php">Gestion des contenants</a></li>
        <li style="margin-left:10px;color:white;"><a href="depollution.php">Dépollution de véhicules</a></li>
        <li style="margin-left:10px;color:white;"><a href="dechets.php">Gestion des déchets</a></li>
        <li style="margin-left:10px;color:white;"><a href="ademe.php">ADEME/SYDEREP</a></li>
    </ol>
<br>

<h3><center>Paramètres</center></h3>

    <ol>
        <li style="margin-left:10px;color:white;"><a href="paramlogiciel.php">Interface et logiciel</a></li>
        <li style="margin-left:10px;color:white;"><a href="intervenants.php">Intervenants et tiers</a></li>
        <li style="margin-left:10px;color:white;"><a href="infospersos.php">Vos informations</a></li>
        <li style="margin-left:10px;color:white;"><a href="deroulantes.php">Listes déroulantes</a></li>
    </ol>
<br>

<h3><center>Statistiques</center></h3>

    <ol>
        <li style="margin-left:10px;color:white;"><a href="stats.php">Vos statistiques</a></li>
    </ol>

<br>
<a href="https://www.vhu2.fr/#equipe"><center>Si vous souhaitez contacter l'équipe VHU2 :</center></a><br>

<a href="mailto:sav@vhu2.fr"><center><img style="width: 100% ;" src="sav.png"/></center></a><br>
<br>

       </div></nav></html>         <body>

    <section>

   <h1>Quels sont les avantages de VHU2 ?</h1>

<h2>I. Présentation</h2>

    <img style="width: 95% ;" src="shemaglobalV2.png" alt="e">
    <br>
    <br>

    <p>
    VHU2 est un logiciel de gestion qui permet de gérer tous les aspects liés aux activités des centres VHU.<br><br>
    En effet, il est pensé pour optimiser :<br><br>
    - la gestion des VHU, VA ou même VO qui sont groupés en tant que <u>dossiers</u>,<br><br>
    - la gestion des PRE et PN qui sont groupées en tant qu'<u>articles</u>,<br><br>
    - la gestion de votre stock de pièces,<br><br>
    - la facturation avec la possibilité de rédiger et d'imprimer factures, tickets, bons de livraison, devis ou encore avoirs. 
    </p>

    <p>
    Notre logiciel est également directement lié à des <a href="interfaces.php">services</a> extérieurs qui permettent d’assurer un complément dans la gestion globale de votre activité, tels que <a href="misiv.php"> MiSIV </a> qui permet de réaliser vos démarches SIV simplement depuis le logiciel.
    </p> 

    <img src="1.png" class="img1"  alt="Photo de montagne" />
    <br>
    <br>

	<p>
        Pour gagner du temps, VHU2 est compatible avec de nombreux <a href="periph.php">périphériques</a> comme les <a href="douchette.php"> douchettes</a> qui vous permettent de scanner des codes-barres pour les pièces mais aussi pour les factures imprimées. Ces codes-barres sont générés automatiquement par le logiciel.<br>
    </p>

	<p>
        Plus concrètement, notre logiciel vous aidera à optimiser votre gestion des VHU mais aussi des pièces détachées ou des prestations.
    </p>

    <img src="2.png" class="img2" alt="e" />
    <br>
    <br>

<h2>II. Dossiers</h2>

    <p>
        VHU2 offre ainsi la possibilité de gérer totalement le cycle de vie et le stockage en temps réel de vos VHU en vous permettant de réaliser de nombreuses actions :</p>
    <p>
	  Vous pourrez évidemment commencer par <a href="ajouterparc.php">  ajouter des VHU dans votre parc,</a><br>
    </p>

    <img src="nouvdoss.png" alt="Photo de montagne" />
    <br>
    <br>
    
    <p>
        leur entrée au <a href="livrepolice.php"> livre de police</a> se fera alors d’elle-même.<br>
    </p>
    
    <img src="lp.png" alt="Photo de montagne" />
    <br>
    <br>

    <p>
        Pour gagner du temps, vous pourrez également gérer <a href="ajouterlot.php"> l'entrée </a><br>
    </p>
    
    <img src="entlot1.png" alt="Photo de montagne" />
    <br>
    <br>

    <p>
        et la <a href="retirerlot.php">   sortie de ces VHU par lots</a>.<br>
    </p>

    <img src="sorlot1.png" alt="Photo de montagne" />
    <br>
    <br>

    <p>
        Vous pourrez ensuite à votre guise, consulter et organiser votre <a href="gestionparc.php"> parc.</a><br>
    </p>

    <img src="parcsiv.png" alt="Photo de montagne" />
    <br>
    <br>

    <p>
        La gestion des <a href="enlevements.php"> enlèvements</a> se fait également directement dans le logiciel.<br>
    </p>
    
    <img src="enlevement2.png" alt="Photo de montagne" />
    <br>
    <br>

    <p>
        Tout comme celle des <a href=offres.php>  appels d'offres </a> que vous pourrez consigner dans une section dédiée.
    </p>
    
    <img src="offres1.png" alt="Photo de montagne" />
    <br>
    <br>

    <p>
        Notre liaison avec notre partenaire <a href="darva.php"> DARVA </a> permettra même la gestion des assurances et celle avec <a  href="misiv.php">MiSIV </a> vous donnera la possibilité de réaliser vos démarches SIV. <br>
    </p>

    <br>

<h2>III. Articles</h2>

    <p>
        Mais comme votre travail ne se résume pas aux véhicules, nous offrons aussi la possibilité de gérer le stockage de vos pièces en attente d’être vendues :<br>
    </p>

    <p>
        De manière assez classique, vous pourrez ainsi <a href="ajoutpiece.php">  ajouter une nouvelle pièce</a> à votre stock, les pièces pouvant être réparties dans différents groupes et sous-groupes comme illustré ci-dessous :<br>
    </p>

    <img src="typespiècesvoiture.png" alt="Photo de montagne" />
    <br>
    <br>

    <img src="typespiècesmoto.png" alt="Photo de montagne" />
    <br>
    <br>

    <p>   
        Nos<a href="demontage.php"> fiches de démontage</a> vous permettront d’ajouter facilement et rapidement, toutes les pièces d’un même véhicule, avec la possibilité d’imprimer cette fiche pour faciliter le travail de l’opérateur.<br>
    </p>

    <img src="demontage2.png" alt="Photo de montagne" />
    <br>
    <br>

    <p>
        Pas d’inquiétude, il est aussi possible d’<a href="importcatalogue.php">importer toutes vos données</a> depuis un catalogue ou un fichier Excel, il ne sera pas nécessaire de tout recopier.<br>
    </p>

    <p>
        Une fois vos pièces en stock, vous pourrez toutes les gérer dans un <a href="catalogue.php"> catalogue</a> simple d’utilisation, puisque notre mécanisme de <a href="rech.tri.php"> tri et de recherche</a> est très instinctif, même avec des milliers de références.<br>
    </p>

    <img src="catalogue1.png" alt="Photo de montagne" />
    <br>
    <br>

    <p>
       L’intégralité des <a href="migrations.php"> migrations</a> de vos pièces sera enregistrée et vous pourrez connaitre à chaque instant l’évolution de vos stocks.<br>
    </p>

    <p>
    </p><img src="migrations2.png" alt="Photo de montagne" />

    <p>
        Et enfin, nous vous offrons la possibilité de lier VHU2 avec votre <a href="ecommerce.php"> page e-commerce</a> pour une actualisation des stocks automatisée lors de vos ventes en ligne.<br>
    </p>


<h2>IV. Facturation</h2>

  <p>
    Notre logiciel assure également tout l’aspect commercial et financier de votre entreprise, en accord avec les nouvelles règlementations sur les logiciels de gestion financière. Ainsi, vous pourrez facilement <a href="facturation.php">rédiger et imprimer vos factures, tickets, bons de livraison, avoirs ou devis</a>.<br>
  </p>

  <p>
    La <a href="facturevehicule.php">vente de véhicules</a> est également prise en charge ainsi que toutes les démarches qui l’accompagnent.<br>
  </p>

  <img src="ventevehicule2.png" alt="Photo de montagne" />
  <br>
  <br>

  <p>
    La transformation de vos <a href="bl.php"> bons de livraison</a> en fin de mois se gère elle aussi automatiquement.<br>
  </p>

  <img src="bl1.png" alt="Photo de montagne" />
  <br>
  <br>

  <p>
    Vous aurez aussi la possibilité de consulter votre <a href="journal.php"> journal de vente</a> et votre <a href="inventaire.php"> inventaire de caisse</a>.<br>
  </p>

  <img src="journal2.png" alt="Photo de montagne" />
  <br>
  <br>

  <p>
    La <a href="comptabilite.php">comptabilité</a> est également exportable depuis VHU2 directement vers votre logiciel de comptabilité personnel.<br>
  </p>

  <img src="compta2.png" alt="Photo de montagne" />
  <br>
  <br>

<h2>V.	Dépollution</h2>

    <p>
        Rédiger votre déclaration annuelle pour l’<a href="ademe.php">ADEME/SYDEREP</a> peut être long et contraignant, mais VHU2 est capable de récupérer toutes les informations nécessaires dans votre base de données pour effectuer cette déclaration.<br> 
    </p>
  
  <img src="ademe2.png" alt="Photo de montagne" />
  <br>
  <br>
  
<h2>VI. Paramétrages</h2>

	<p>
        VHU2 est un logiciel très flexible et il est possible de le modeler à votre guise, pour gagner en temps et en efficacité.<br> 
    </p>
  
    <p>
        Vous pourrez ainsi personnaliser la majorité des fenêtres pour qu’elles correspondent à votre manière de travailler ainsi que tous les documents imprimables, pour y faire figurer ce que vous désirez en renseignant les <a href="infospersos.php">  informations concernant votre entreprise.</a> Une fois cela fait, vous n’aurez plus besoin de le faire sur l’intégralité des documents et autres déclarations SIV.<br>
    </p>

  <p>
    Et en renseignant toutes les <a href="intervenants.php"> données sur vos clients, fournisseurs ou experts</a>, vous pourrez les retrouver rapidement dans toutes les sections du logiciel.<br>
  </p>

  <p>
    Enfin, VHU2 vous permet de consulter de très nombreuses <a href="stats.php">statistiques</a> concernant vos ventes.<br>
  </p>

  <img src="stats7.png" alt="Photo de montagne" />
  <br>
  <br>

<p>
    Pour résumer, VHU2 est très complet et autonome, il fait seul le lien avec tous les aspects de votre métier et embarque toutes les fonctionnalités qui pourraient vous être utiles.<br>
    <br>
    Sans oublier que notre équipe est sans cesse à votre écoute pour apporter des améliorations dont vous auriez besoin.<br>
</p>
<br>

</section></body>
<footer></footer>
    
    
</html>