   <!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8" />
        <title>Documentation - VHU2</title>
    </head> 

<!DOCTYPE html>
<html>  

<!--


ê
-->
<!--
Liste à améliorer en priorité:
-appli mobile
DARVA
-misiv
-global pre
-team viewer
-site ecommerce
-importer catalogue
-déchets dépollution
-Interface et logiciel 
-->


  




    <head>

        <meta charset="utf-8" />
         <link rel="stylesheet" href="style.css"/>
        <title>Qu'est-il possible de faire avec VHU2 ?</title>

    </head>
   
    <nav id="sommaire">        
    <div class="element_sommaire">
        
      

    <a href="https://www.cardiffvhu2.fr/" id="green"> <img style="width: 100% ;" src="logo vhu2.png"></a>
   
    <a style="display:flex;"href="https://www.youtube.com/playlist?list=PLcUB3Tm73B0EXawxHPw9PEJBR7PLWFJeE"><img src="cam.png" alt="e"><p><div style="font-size:13px;"><br>Retrouvez ici des tutoriels vidéos</div></p></a>

<h3><center>Environnement de VHU2</center></h3>

    <ol>
        <li style="margin-left:10px; color:white;"><a href="index.php">Présentation générale</a></li>
        <li style="margin-left:10px; color:white;"><a href="periph.php">Périphériques </a></li>
            <ul>
                <li  style="color:white;"><a href="douchette.php">Douchette </a></li>
                <li  style="color:white;"><a href="appli.php">Application mobile</a></li>
                <li  style="color:white;"><a href="imprimantes.php">Imprimantes</a></li>
            </ul>
        <li style="margin-left:10px;color:white;"><a href="interfaces.php">Interfaces</a></li>
            <ul>
                <li style="color:white;"><a  href="aaa.php">3A </a></li>
                <li style="color:white;"><a  href="darva.php">DARVA</a></li>
                <li style="color:white;"><a  href="misiv.php">MiSIV-TMS (SIV)</a></li>
                <li style="color:white;"><a  href="globalpre.php">Global PRE</a></li>
                <li style="color:white;"><a  href="teamviewer.php">TeamViewer</a></li>
                <li style="color:white;"><a  href="ecommerce.php">Sites e-commerce </a></li>
            </ul>
        <li style="margin-left:10px;color:white;"><a href="rech.tri.php">Recherche-tri</a></li>
    </ol>
<br>

<h3><center>Dossiers (véhicules)</center></h3>

    <ol>
        <li style="margin-left:10px;color:white;"><a href="ajouterparc.php">Ajouter un véhicule</a></li>
        <li style="margin-left:10px;color:white;"><a href="livrepolice.php">Livre de police</a></li>
        <li style="margin-left:10px;color:white;"><a href="gestionparc.php">Gestion du parc </a></li>
        <li style="margin-left:10px;color:white;"><a href="enlevements.php">Gérer les enlèvements</a></li>
        <li style="margin-left:10px;color:white;"><a href="offres.php">Gérer les appels d'offres</a></li>
        <li style="margin-left:10px;color:white;"><a href="lots.php">Gestion par lots</a></li>
            <ul>
                <li  style="color:white;"><a href="ajouterlot.php">Ajouter un lot</a></li>
                <li  style="color:white;"><a href="retirerlot.php">Retirer un lot</a></li>
            </ul>
    </ol>
<br>

<h3><center>Articles (pièces)</center></h3>

    <ol>
        <li style="margin-left:10px;color:white;"><a href="ajoutpiece.php">Ajouter des pièces</a></li>
        <li style="margin-left:10px;color:white;"><a href="demontage.php">Fiches de démontage</a></li>
        <li style="margin-left:10px;color:white;"><a href="catalogue.php">Visualiser le catalogue</a></li>
        <li style="margin-left:10px;color:white;"><a href="migrations.php">Visualiser les migrations</a></li>
        <li style="margin-left:10px;color:white;"><a href="importcatalogue.php">Importer un catalogue</a></li>
    </ol>
<br>

<h3><center>Gestion financière</center></h3>

    <ol>
        <li style="margin-left:10px;color:white;"><a href="facturation.php">Outil facturation</a></li>
        <li style="margin-left:10px;color:white;"><a href="facturevehicule.php">Facturation de véhicule</a></li>
        <li style="margin-left:10px;color:white;"><a href="proformas.php">Proformas et documents</a></li>
        <li style="margin-left:10px;color:white;"><a href="bl.php">Bons de livraison</a></li>
        <li style="margin-left:10px;color:white;"><a href="comptabilite.php">Interface comptable</a></li>
        <li style="margin-left:10px;color:white;"><a href="journal.php">Journal de vente</a></li>
        <li style="margin-left:10px;color:white;"><a href="inventaire.php">Inventaire de caisse</a></li>
    </ol>   
<br>

<h3><center>Dépollution</center></h3>

    <ol>
        <li style="margin-left:10px;color:white;"><a href="contenants.php">Gestion des contenants</a></li>
        <li style="margin-left:10px;color:white;"><a href="depollution.php">Dépollution de véhicules</a></li>
        <li style="margin-left:10px;color:white;"><a href="dechets.php">Gestion des déchets</a></li>
        <li style="margin-left:10px;color:white;"><a href="ademe.php">ADEME/SYDEREP</a></li>
    </ol>
<br>

<h3><center>Paramètres</center></h3>

    <ol>
        <li style="margin-left:10px;color:white;"><a href="paramlogiciel.php">Interface et logiciel</a></li>
        <li style="margin-left:10px;color:white;"><a href="intervenants.php">Intervenants et tiers</a></li>
        <li style="margin-left:10px;color:white;"><a href="infospersos.php">Vos informations</a></li>
        <li style="margin-left:10px;color:white;"><a href="deroulantes.php">Listes déroulantes</a></li>
    </ol>
<br>

<h3><center>Statistiques</center></h3>

    <ol>
        <li style="margin-left:10px;color:white;"><a href="stats.php">Vos statistiques</a></li>
    </ol>

<br>
<a href="https://www.vhu2.fr/#equipe"><center>Si vous souhaitez contacter l'équipe VHU2 :</center></a><br>

<a href="mailto:sav@vhu2.fr"><center><img style="width: 100% ;" src="sav.png"/></center></a><br>
<br>

       </div></nav></html>         

    <section>

<h1> Ajouter un nouveau véhicule </h1>

<br>
<br>

<iframe width="560" height="315" src="https://www.youtube.com/embed/HNczYgTgT3k" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

<br>
<br>

<p>
    Que serait votre parc de VHU sans VHU ? 
<p/>
        
<p>
    Voilà donc comment en ajouter très rapidement à votre parc :<br>
    <br>
    Rendez vous dans <u>Gestion des dossiers</u> via le menu principal puis dans <u>Ajouter un véhicule</u>.
    <br>
</p>

<img style="width: 60%;" src="nouvdoss.png">

<p><br>
    Remplissez alors simplement un maximum d'informations, notez également que si vous avez rempli <a href="infospersos.php">vos informations</a> et <a href="intervenants.php">celles sur vos partenaires</a>, vous n'avez plus qu'à les chercher dans les <a href="deroulantes.php">  Listes déroulantes</a>, cela vous fera gagner beaucoup de temps. N'hésitez pas à aller voir les pages dédiées puis à remplir ces paramètres !<br>
    Notez également que vous pouvez utiliser le service <a href="aaa.php">3A</a> pour remplir rapidemment les informations sur le véhicule.
</p>

<p>
    Dans tous les cas vous devriez avoir rempli une grande partie des informations.
    <br>
</p>

<img style="width: 60%;" src="nouvplein.png">

<p><br>
    Vous pouvez maintenant ajouter des photos ou bien consulter celles prises via <a href="appli.php">l'application mobile</a> ou encore réaliser toutes vos <a href="misiv.php">démarches SIV</a>.<br>
</p>

<img style="width: 60%;" src="nouvsiv.png">

<p><br>
    Vous n'avez plus qu'à cliquer sur <u>Entrée au parc</u> en bas à droite et le véhicule sera automatiquement doté d'un <a href="livrepolice.php">numéro de livre de police</a>.<br>
    <br>
    Si vous souhaitez choisir manuellement chaque numéro de livre de police ou repartir d'un numéro spécifique, c'est une option débloquable seulement par nos techniciens, contactez le SAV et nous serons ravis de vous aider.<br>
</p>

</section>
<footer></footer>
    
    </body>
</html>