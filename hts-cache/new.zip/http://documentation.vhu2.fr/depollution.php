 <!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8" />
        <title>Documentation - VHU2</title>
    </head> 

<!DOCTYPE html>
<html>  

<!--


ê
-->
<!--
Liste à améliorer en priorité:
-appli mobile
DARVA
-misiv
-global pre
-team viewer
-site ecommerce
-importer catalogue
-déchets dépollution
-Interface et logiciel 
-->


  




    <head>

        <meta charset="utf-8" />
         <link rel="stylesheet" href="style.css"/>
        <title>Qu'est-il possible de faire avec VHU2 ?</title>

    </head>
   
    <nav id="sommaire">        
    <div class="element_sommaire">
        
      

    <a href="https://www.cardiffvhu2.fr/" id="green"> <img style="width: 100% ;" src="logo vhu2.png"></a>
   
    <a style="display:flex;"href="https://www.youtube.com/playlist?list=PLcUB3Tm73B0EXawxHPw9PEJBR7PLWFJeE"><img src="cam.png" alt="e"><p><div style="font-size:13px;"><br>Retrouvez ici des tutoriels vidéos</div></p></a>

<h3><center>Environnement de VHU2</center></h3>

    <ol>
        <li style="margin-left:10px; color:white;"><a href="index.php">Présentation générale</a></li>
        <li style="margin-left:10px; color:white;"><a href="periph.php">Périphériques </a></li>
            <ul>
                <li  style="color:white;"><a href="douchette.php">Douchette </a></li>
                <li  style="color:white;"><a href="appli.php">Application mobile</a></li>
                <li  style="color:white;"><a href="imprimantes.php">Imprimantes</a></li>
            </ul>
        <li style="margin-left:10px;color:white;"><a href="interfaces.php">Interfaces</a></li>
            <ul>
                <li style="color:white;"><a  href="aaa.php">3A </a></li>
                <li style="color:white;"><a  href="darva.php">DARVA</a></li>
                <li style="color:white;"><a  href="misiv.php">MiSIV-TMS (SIV)</a></li>
                <li style="color:white;"><a  href="globalpre.php">Global PRE</a></li>
                <li style="color:white;"><a  href="teamviewer.php">TeamViewer</a></li>
                <li style="color:white;"><a  href="ecommerce.php">Sites e-commerce </a></li>
            </ul>
        <li style="margin-left:10px;color:white;"><a href="rech.tri.php">Recherche-tri</a></li>
    </ol>
<br>

<h3><center>Dossiers (véhicules)</center></h3>

    <ol>
        <li style="margin-left:10px;color:white;"><a href="ajouterparc.php">Ajouter un véhicule</a></li>
        <li style="margin-left:10px;color:white;"><a href="livrepolice.php">Livre de police</a></li>
        <li style="margin-left:10px;color:white;"><a href="gestionparc.php">Gestion du parc </a></li>
        <li style="margin-left:10px;color:white;"><a href="enlevements.php">Gérer les enlèvements</a></li>
        <li style="margin-left:10px;color:white;"><a href="offres.php">Gérer les appels d'offres</a></li>
        <li style="margin-left:10px;color:white;"><a href="lots.php">Gestion par lots</a></li>
            <ul>
                <li  style="color:white;"><a href="ajouterlot.php">Ajouter un lot</a></li>
                <li  style="color:white;"><a href="retirerlot.php">Retirer un lot</a></li>
            </ul>
    </ol>
<br>

<h3><center>Articles (pièces)</center></h3>

    <ol>
        <li style="margin-left:10px;color:white;"><a href="ajoutpiece.php">Ajouter des pièces</a></li>
        <li style="margin-left:10px;color:white;"><a href="demontage.php">Fiches de démontage</a></li>
        <li style="margin-left:10px;color:white;"><a href="catalogue.php">Visualiser le catalogue</a></li>
        <li style="margin-left:10px;color:white;"><a href="migrations.php">Visualiser les migrations</a></li>
        <li style="margin-left:10px;color:white;"><a href="importcatalogue.php">Importer un catalogue</a></li>
    </ol>
<br>

<h3><center>Gestion financière</center></h3>

    <ol>
        <li style="margin-left:10px;color:white;"><a href="facturation.php">Outil facturation</a></li>
        <li style="margin-left:10px;color:white;"><a href="facturevehicule.php">Facturation de véhicule</a></li>
        <li style="margin-left:10px;color:white;"><a href="proformas.php">Proformas et documents</a></li>
        <li style="margin-left:10px;color:white;"><a href="bl.php">Bons de livraison</a></li>
        <li style="margin-left:10px;color:white;"><a href="comptabilite.php">Interface comptable</a></li>
        <li style="margin-left:10px;color:white;"><a href="journal.php">Journal de vente</a></li>
        <li style="margin-left:10px;color:white;"><a href="inventaire.php">Inventaire de caisse</a></li>
    </ol>   
<br>

<h3><center>Dépollution</center></h3>

    <ol>
        <li style="margin-left:10px;color:white;"><a href="contenants.php">Gestion des contenants</a></li>
        <li style="margin-left:10px;color:white;"><a href="depollution.php">Dépollution de véhicules</a></li>
        <li style="margin-left:10px;color:white;"><a href="dechets.php">Gestion des déchets</a></li>
        <li style="margin-left:10px;color:white;"><a href="ademe.php">ADEME/SYDEREP</a></li>
    </ol>
<br>

<h3><center>Paramètres</center></h3>

    <ol>
        <li style="margin-left:10px;color:white;"><a href="paramlogiciel.php">Interface et logiciel</a></li>
        <li style="margin-left:10px;color:white;"><a href="intervenants.php">Intervenants et tiers</a></li>
        <li style="margin-left:10px;color:white;"><a href="infospersos.php">Vos informations</a></li>
        <li style="margin-left:10px;color:white;"><a href="deroulantes.php">Listes déroulantes</a></li>
    </ol>
<br>

<h3><center>Statistiques</center></h3>

    <ol>
        <li style="margin-left:10px;color:white;"><a href="stats.php">Vos statistiques</a></li>
    </ol>

<br>
<a href="https://www.vhu2.fr/#equipe"><center>Si vous souhaitez contacter l'équipe VHU2 :</center></a><br>

<a href="mailto:sav@vhu2.fr"><center><img style="width: 100% ;" src="sav.png"/></center></a><br>
<br>

       </div></nav></html>       <body> 

<section>
        <h1>Dépollution de véhicules</h1>

<p>
    Pour effectuer sur VHU2 la dépollution d'un véhicule, deux choix s'offrent à vous :<br>
    <br>
    - soit vous passez par la fiche du véhicule qui vous intéresse,<br>
    <br>
    - soit vous passez par le suivi de dépollution.<br>
</p>

<h2>Via la fiche du véhicule</h2>

<p>
    Il vous est possible d'effectuer la dépollution d'un véhicule en enregistrant les déchets directement depuis la <a href="gestionparc.php">fiche d'un véhicule</a>, consutable lors de l'entrée d'un véhicule au stock ou bien à tout moment en consultant votre parc. Pour cela, il suffit de cliquer sur <u>Dépollution</u> en bas à droite.<br>
</p>

<img style="width: 50% ;"src="depollution1_ficheVHU.png">
<br>
<br>

<p>                       
    Une nouvelle fenêtre apparaît. Cliquez ensuite sur <u>Nouveau</u> pour rentrer un nouveau déchet.<br>
</p>

<img style="width: 50% ;" src="depollution2_listedechets.png">
<br>
<br>

<p>
    Via cette fenêtre, vous pouvez sélectionner le déchet, sa quantité, à quelle date et par qui cela a été exécuté. 
    Egalement, on retrouve ici la liste des contenants que vous avez pu créer dans la <a href="contenants.php">section précédente</a>. Vous n'avez plus qu'à sélectionner le contenant désiré puis à valider.<br>
</p>

<img style="width: 50% ;" src="contenants8_depollution.png"> 
<br>
<br>

<img style="width: 35% ;" src="depollution3_ajoutdechetdepollution.png">
<br>
<br>

<p>
    En cliquant sur la loupe, vous retrouverez plus de détails concernant les paramétrages des déchets. Choisissez le type de déchet dans la liste à gauche puis paramétrez à votre guise les différentes informations sur la droite. <br>
</p>

<img style="width: 35% ;" src="depollution4_parametragedechets.png">
<br>
<br>

<h2>Via le suivi de dépollution</h2>

<p>
    Depuis le menu principal, cliquez sur le <u>Suivi de dépollution</u>.
    Vous avez ici accès à plusieurs outils.<br>
</p>

<img style="width: 30%;" src="depollution5_menuprincipalsuividepollution.png" /> <img style="width: 30%;" src="depollution6_suividepollution.png">
<br>
<br>

<h3><u>Saisie des dépollutions (en cascade) :</u></h3>

<p>
    En cliquant ici, vous accéderez à un outil de saisie rapide de l'opération de dépollution d'un véhicule.<br>
    <br>
    Entrez d'abord l'immatriculation du véhicule ou bien son numéro de livre de police puis cliquez sur <u>Rechercher</u>.<br>
    <br>
    Double-cliquez ensuite sur la 1ère ligne sous les intitulés de colonnes pour remplir les informations concernant le déchet dépollué.<br>
</p>

<img style="width: 60%;" src="depollution7_saisiecascade.png" >
<br>
<br>

<h3><u>Suivi des dépollutions par contenants ou véhicules :</u></h3>

<p>
    En cliquant ici, vous pourrez consulter les informations concernant la dépollution (véhicules, déchets, contenants, quantités) en les triant par rapport à une période, un véhicule ou un type de déchet.<br>
</p>

<img style="width: 80%;" src="depollution8_suividesdepollutions.png" >
<br>
<br>

</section>
</body>
</html>