 <!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8" />
        <title>Documentation - VHU2</title>
    </head> 

<!DOCTYPE html>
<html>  

<!--


ê
-->
<!--
Liste à améliorer en priorité:
-appli mobile
DARVA
-misiv
-global pre
-team viewer
-site ecommerce
-importer catalogue
-déchets dépollution
-Interface et logiciel 
-->


  




    <head>

        <meta charset="utf-8" />
         <link rel="stylesheet" href="style.css"/>
        <title>Qu'est-il possible de faire avec VHU2 ?</title>

    </head>
   
    <nav id="sommaire">        
    <div class="element_sommaire">
        
      

    <a href="https://www.cardiffvhu2.fr/" id="green"> <img style="width: 100% ;" src="logo vhu2.png"></a>
   
    <a style="display:flex;"href="https://www.youtube.com/playlist?list=PLcUB3Tm73B0EXawxHPw9PEJBR7PLWFJeE"><img src="cam.png" alt="e"><p><div style="font-size:13px;"><br>Retrouvez ici des tutoriels vidéos</div></p></a>

<h3><center>Environnement de VHU2</center></h3>

    <ol>
        <li style="margin-left:10px; color:white;"><a href="index.php">Présentation générale</a></li>
        <li style="margin-left:10px; color:white;"><a href="periph.php">Périphériques </a></li>
            <ul>
                <li  style="color:white;"><a href="douchette.php">Douchette </a></li>
                <li  style="color:white;"><a href="appli.php">Application mobile</a></li>
                <li  style="color:white;"><a href="imprimantes.php">Imprimantes</a></li>
            </ul>
        <li style="margin-left:10px;color:white;"><a href="interfaces.php">Interfaces</a></li>
            <ul>
                <li style="color:white;"><a  href="aaa.php">3A </a></li>
                <li style="color:white;"><a  href="darva.php">DARVA</a></li>
                <li style="color:white;"><a  href="misiv.php">MiSIV-TMS (SIV)</a></li>
                <li style="color:white;"><a  href="globalpre.php">Global PRE</a></li>
                <li style="color:white;"><a  href="teamviewer.php">TeamViewer</a></li>
                <li style="color:white;"><a  href="ecommerce.php">Sites e-commerce </a></li>
            </ul>
        <li style="margin-left:10px;color:white;"><a href="rech.tri.php">Recherche-tri</a></li>
    </ol>
<br>

<h3><center>Dossiers (véhicules)</center></h3>

    <ol>
        <li style="margin-left:10px;color:white;"><a href="ajouterparc.php">Ajouter un véhicule</a></li>
        <li style="margin-left:10px;color:white;"><a href="livrepolice.php">Livre de police</a></li>
        <li style="margin-left:10px;color:white;"><a href="gestionparc.php">Gestion du parc </a></li>
        <li style="margin-left:10px;color:white;"><a href="enlevements.php">Gérer les enlèvements</a></li>
        <li style="margin-left:10px;color:white;"><a href="offres.php">Gérer les appels d'offres</a></li>
        <li style="margin-left:10px;color:white;"><a href="lots.php">Gestion par lots</a></li>
            <ul>
                <li  style="color:white;"><a href="ajouterlot.php">Ajouter un lot</a></li>
                <li  style="color:white;"><a href="retirerlot.php">Retirer un lot</a></li>
            </ul>
    </ol>
<br>

<h3><center>Articles (pièces)</center></h3>

    <ol>
        <li style="margin-left:10px;color:white;"><a href="ajoutpiece.php">Ajouter des pièces</a></li>
        <li style="margin-left:10px;color:white;"><a href="demontage.php">Fiches de démontage</a></li>
        <li style="margin-left:10px;color:white;"><a href="catalogue.php">Visualiser le catalogue</a></li>
        <li style="margin-left:10px;color:white;"><a href="migrations.php">Visualiser les migrations</a></li>
        <li style="margin-left:10px;color:white;"><a href="importcatalogue.php">Importer un catalogue</a></li>
    </ol>
<br>

<h3><center>Gestion financière</center></h3>

    <ol>
        <li style="margin-left:10px;color:white;"><a href="facturation.php">Outil facturation</a></li>
        <li style="margin-left:10px;color:white;"><a href="facturevehicule.php">Facturation de véhicule</a></li>
        <li style="margin-left:10px;color:white;"><a href="proformas.php">Proformas et documents</a></li>
        <li style="margin-left:10px;color:white;"><a href="bl.php">Bons de livraison</a></li>
        <li style="margin-left:10px;color:white;"><a href="comptabilite.php">Interface comptable</a></li>
        <li style="margin-left:10px;color:white;"><a href="journal.php">Journal de vente</a></li>
        <li style="margin-left:10px;color:white;"><a href="inventaire.php">Inventaire de caisse</a></li>
    </ol>   
<br>

<h3><center>Dépollution</center></h3>

    <ol>
        <li style="margin-left:10px;color:white;"><a href="contenants.php">Gestion des contenants</a></li>
        <li style="margin-left:10px;color:white;"><a href="depollution.php">Dépollution de véhicules</a></li>
        <li style="margin-left:10px;color:white;"><a href="dechets.php">Gestion des déchets</a></li>
        <li style="margin-left:10px;color:white;"><a href="ademe.php">ADEME/SYDEREP</a></li>
    </ol>
<br>

<h3><center>Paramètres</center></h3>

    <ol>
        <li style="margin-left:10px;color:white;"><a href="paramlogiciel.php">Interface et logiciel</a></li>
        <li style="margin-left:10px;color:white;"><a href="intervenants.php">Intervenants et tiers</a></li>
        <li style="margin-left:10px;color:white;"><a href="infospersos.php">Vos informations</a></li>
        <li style="margin-left:10px;color:white;"><a href="deroulantes.php">Listes déroulantes</a></li>
    </ol>
<br>

<h3><center>Statistiques</center></h3>

    <ol>
        <li style="margin-left:10px;color:white;"><a href="stats.php">Vos statistiques</a></li>
    </ol>

<br>
<a href="https://www.vhu2.fr/#equipe"><center>Si vous souhaitez contacter l'équipe VHU2 :</center></a><br>

<a href="mailto:sav@vhu2.fr"><center><img style="width: 100% ;" src="sav.png"/></center></a><br>
<br>

       </div></nav></html>       <body>  

    <section>
    	
<h1>Interface comptable</h1>

<h2>Explications concernant la comptabilité</h2>

<p>
    Tout d'abord, voici quelques explications concernant la comptabilité générale. <br>
    <br>
    <br>
    Dans un premier temps il faut faire la différence entre les comptes de bilan (1 à 5) qui serviront à élaborer le bilan en fin d’exercice et les comptes de gestion (6 et 7) qui vont concerner le compte de résultat.  <br>
    <br>
    Pour les comptes de bilan (1 à 5), ils vont être utilisés pour recenser les opérations qui affectent le patrimoine de l’entreprise : Trésorerie, outillage, ordinateurs, stocks de pièces et de voitures. <br>
    <br>
    Pour les comptes de gestion servant au compte de résultat (6 et 7) ils vont être utilisés pour mesurer les achats et les ventes de l’entreprise. Ces comptes vont concerner les achats "6" (achats de matériels, achats de véhicules, achats de pièces) et les ventes "7" (ventes de pièces détachées PRE ou PN, ventes de prestations et ventes de véhicules VA/VO/carcasses). <br>
    <br>
</p>

<br>
<img style="width: 60%;"src="Tableau Comptes.png">
<br>
<br>

<p>
    Dans les opérations du quotidien qui sont enregistrées dans VHU2, il faut utiliser principalement les comptes suivants : <br>
    <br>
</p>
<br>

<img src="tableau compte utile VHU2 .png">

<br>
<br>
<br>
<p>
  Pour chaque classe, un journal permet de lister les opérations. Dans le logiciel VHU2 il y a le journal des ventes (classe 7) disponible et éditable avec l'ensemble des factures, bons de livraisons, tickets et avoirs. <br>
  <br>
  Les écritures comptables dans VHU2 concernent uniquement les achats et les ventes. <br>
  <br>
  Voici un exemple simple d’écritures d’achats et de ventes que le logiciel peut éditer et exporter vers le format d'un logiciel de comptabilité (ex : sage, ciel, EBP, etc). <br>
  <br>
  <br>
</p>
  <img style="width: 35%;"src="Ecritures achats et ventes .png">
<br>
<br>
<p>
    La méthodologie restera la même que ce soit de la vente de marchandises (véhicules ou pièces détachées) ou de l’achat de fournitures (véhicules ou pièces détachées). <br>
    <br>
    Seuls les taux de TVA peuvent changer (0, 5.5, 10 et 20%). Il se peut aussi qu’il y ait des acomptes, du transport à rajouter. Nous avons ici un exemple de facture simple. Le total du débit doit toujours être égal au total du crédit.  <br>
    <br>
    <br>
    
<h2>Fonctionnement des comptes dans VHU2. </h2>

<p>
Les comptes de la classe 4 : (compte tiers, fournisseurs, clients et TVA)<br>
<br>
<br>
-   Les comptes fournisseurs (401) et les comptes clients (411) : Ils sont présents dans chaque écriture comptable concernant un achat ou une vente. Afin de les différencier, la méthode la plus simple est de mettre les 3 premiers chiffres du compte avec les 3 premières lettres du fournisseur.<br>
Exemple : Le fournisseur Lasserre va être renommé dans la compta 401LAS et le client Gaujacq va être renommé 411GAU. <br>
<br>
-   Les comptes de TVA : Lors d’une opération d'achat, il faut utiliser la TVA déductible (445660). Lors d’un achat la TVA peut être de 20, 10 ou 0%. Elle est calculée à partir du HT du produit. Elle est toujours comptabilisée au débit du compte.
Pour une opération de vente, il faut utiliser le compte de TVA Collectée (445710). Dans le cadre des centres VHU, la TVA peut être de 20, 10 ou 0% et sera aussi calculée à partir du HT. Elle se comptablise toujours au crédit du compte. <br>
<br>
<br>
Les comptes de la classe 6 : (achats) <br>
<br>
<br>
Il sont utilisés pour les opérations liées aux achats. Le logiciel VHU2 utilise uniquement les comptes d’achats de marchandises (607) et d’approvisionnements/achats stockés (602). Il sont enregistrés au débit du compte. Les montants sont toujours HT et la TVA (445660) est généralement de 20% si l’on achète à des professionnels et de 0% si l’on achète à des particuliers. Dans une écriture d’achat, le compte "6" sera toujours associé à un compte fournisseur.  <br>
<br>
<br>
Les comptes de la classe 7 : (ventes) <br>
<br>
<br>
Ils concernent uniquement les ventes. Le logiciel VHU2 utilise les comptes de ventes de produits finis (701), de ventes de prestations (706) et de ventes de marchandises (707). Ils sont enregistrés au crédit du compte. Comme pour les achats, le montant est HT. Ce compte est souvent utilisé avec le compte 445710 (TVA collectée). La TVA est généralement de 20% si l’on vend à des professionnels et de 0% ou 10% si l’on vend à des particuliers. Dans une écriture de vente, le compte "7" est toujours associé à un compte client. 



<br> 


<p>
    VHU2 permet donc d'extraire les données comptables de votre activité dans un fichier exportable et utilisable dans votre propre logiciel comptable.<br>
    <br>
    Il convient donc de renseigner le plus d'informations possibles dans VHU2 pour exporter un fichier le plus complet possible.<br>
    <br>
</p>

<h2>Explications concernant la TVA</h2>

<p>
    Voici maintenant des explications concernant la taxation de la TVA.<br>
    <br>
    <br>
    Il existe plusieurs catégories d’opérations imposables à la TVA :<br>
    <br>
    - les <u>opérations imposables par nature</u>, qui concerne les livraisons de biens et prestations de services effectuées par un assujetti à titre onéreux,<br>
    <br>
    - les <u>opérations imposables par décision de la loi</u>, qui concerne les importations et les acquisitions intracommunautaires.<br>
    <br>
    <br>
    Ce sont les règles générales mais il existe un grand nombre d'exceptions et de cas particuliers. Malgré cela, les opérations impliquant des véhicules d'occasion et des pièces automobiles de réemploi sont concernées par la TVA.<br>
    <br>
    Vous trouverez plus de détails dans les schémas ci-dessous.<br>
</p>

<br>
<img src="TVA véhicules.png">
<br>
<br>
<img src="TVA pièces.png">
<br>
<br>

<p>
    Par principe, l’assujetti :<br>
    <br>
    - collecte auprès de ses clients la TVA sur ses ventes pour le compte de l’Etat,<br>
    <br>
    - déduit la TVA que ses fournisseurs lui ont facturée,<br>
    <br>
    - verse, périodiquement, à l’Etat la différence entre la TVA collectée et la TVA déductible.<br>
    <br>
</p>

<p>
    Le schéma suivant décrit la comptabilisation de la TVA selon qu'elle soit collectée ou déductible et quels comptes comptables utiliser :<br>
</p>

<br>
<img src="comptabilisation TVA.png">
<br>
<br>

<p>
    La capture d'écran suivante vous montre un exemple de ce que vous pouvez faire en modifiant la liste de nature de pièces via le <a href="deroulantes.php">paramétrage des listes déroulantes</a>.<br>
    <br>
    Vous pouvez ainsi rentrer un nouveau type de pièce et paramétrer ensuite des éléments comme son type (occasion, neuf, prestation), le type de TVA qui aura été préalablement paramétré ou encore les comptes comptables associés.<br>
</p>

<br>
<img style="width: 100%;"src="screen nature de pièces.png">
<br>
<br>

<h2>L'interface comptable dans votre logiciel VHU2</h2>

<p>
    Après avoir vérifié vos ventes et vos règlements dans le <a href="journal.php">journal de vente</a> et dans l'<a href="inventaire.php">inventaire de caisse</a>, vous pourrez exporter toutes vos données vers votre logiciel de gestion.
    Pour ce faire, cliquez sur <u>Outils</u> depuis le menu principal, puis sur <u>Interface Compta</u>. <br>
</p>

<br>
<img style="width: 30%;" src="appliweb1.png"/> <img style="width: 30%;" src="interface_compta.png">
<br>
<br>

<p>
    Sur cette page, choisissez la période correspondante (écrivez les dates ou bien cliquez sur <u>Période</u> et choisissez une option).<br>
    Cochez ensuite le type de client et la façon dont seront affichées les écritures nulles.<br>
</p>

<br>
<img style="width: 100%;" src="compta1.png">
<br>
<br>

<p>
    Si c'est votre premier export, vous devez régler quelques paramètres. Cliquez donc sur la case <u>Paramètres</u> à droite (vous pouvez aussi cliquer sur <u>Paramétrages</u> depuis le menu principal, puis sur <u>Site</u> et sélectionner l'onglet <u>Comptabilité</u>).<br>
</p>

<br>
<img style="width: 80%;" src="compta2.png">
<br>
<br>

<p>
    Sur cette page vous avez plusieurs éléments paramétrables pour adapter le logiciel à vos besoins, mais un seul est obligatoire.<br>
    <br>
    Renseignez le format de votre logiciel dans la liste déroulante <u>Interface</u>, vous pouvez voir ci-dessus la liste des formats disponibles.<br>
    Vous pouvez saisir en dessous le nom que portera votre export et l'emplacement où il sera enregistré. Par défaut il sera dans C:\CARDIFF\VHU\COMPTA.<br>
    <br>
    Enregistrez donc vos changements en bas à droite et cliquez sur <u>Rechercher</u>. Toutes vos écritures apparaîtront.<br>
</p>

<br>
<img style="width: 100%;" src="compta3.png">
<br>
<br>

<p>
    Si toutes vos écritures sont justes et que l'équilibrage est bon, cliquez sur <u>Exporter</u> en bas à droite.<br>
    Votre fichier est bien créé.<br>
    <br>
    Pour le retrouver, ouvrez l'explorateur de fichiers et suivez ce chemin : C:\CARDIFF\VHU\COMPTA pour retrouver ce fichier, utilisable dans votre logiciel compta.<br>
</p>

<br>

</section>
</body>   
</html>