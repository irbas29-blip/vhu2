    <!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8" />
        <title>Documentation - VHU2</title>
    </head> 

<!DOCTYPE html>
<html>  

<!--


ê
-->
<!--
Liste à améliorer en priorité:
-appli mobile
DARVA
-misiv
-global pre
-team viewer
-site ecommerce
-importer catalogue
-déchets dépollution
-Interface et logiciel 
-->


  




    <head>

        <meta charset="utf-8" />
         <link rel="stylesheet" href="style.css"/>
        <title>Qu'est-il possible de faire avec VHU2 ?</title>

    </head>
   
    <nav id="sommaire">        
    <div class="element_sommaire">
        
      

    <a href="https://www.cardiffvhu2.fr/" id="green"> <img style="width: 100% ;" src="logo vhu2.png"></a>
   
    <a style="display:flex;"href="https://www.youtube.com/playlist?list=PLcUB3Tm73B0EXawxHPw9PEJBR7PLWFJeE"><img src="cam.png" alt="e"><p><div style="font-size:13px;"><br>Retrouvez ici des tutoriels vidéos</div></p></a>

<h3><center>Environnement de VHU2</center></h3>

    <ol>
        <li style="margin-left:10px; color:white;"><a href="index.php">Présentation générale</a></li>
        <li style="margin-left:10px; color:white;"><a href="periph.php">Périphériques </a></li>
            <ul>
                <li  style="color:white;"><a href="douchette.php">Douchette </a></li>
                <li  style="color:white;"><a href="appli.php">Application mobile</a></li>
                <li  style="color:white;"><a href="imprimantes.php">Imprimantes</a></li>
            </ul>
        <li style="margin-left:10px;color:white;"><a href="interfaces.php">Interfaces</a></li>
            <ul>
                <li style="color:white;"><a  href="aaa.php">3A </a></li>
                <li style="color:white;"><a  href="darva.php">DARVA</a></li>
                <li style="color:white;"><a  href="misiv.php">MiSIV-TMS (SIV)</a></li>
                <li style="color:white;"><a  href="globalpre.php">Global PRE</a></li>
                <li style="color:white;"><a  href="teamviewer.php">TeamViewer</a></li>
                <li style="color:white;"><a  href="ecommerce.php">Sites e-commerce </a></li>
            </ul>
        <li style="margin-left:10px;color:white;"><a href="rech.tri.php">Recherche-tri</a></li>
    </ol>
<br>

<h3><center>Dossiers (véhicules)</center></h3>

    <ol>
        <li style="margin-left:10px;color:white;"><a href="ajouterparc.php">Ajouter un véhicule</a></li>
        <li style="margin-left:10px;color:white;"><a href="livrepolice.php">Livre de police</a></li>
        <li style="margin-left:10px;color:white;"><a href="gestionparc.php">Gestion du parc </a></li>
        <li style="margin-left:10px;color:white;"><a href="enlevements.php">Gérer les enlèvements</a></li>
        <li style="margin-left:10px;color:white;"><a href="offres.php">Gérer les appels d'offres</a></li>
        <li style="margin-left:10px;color:white;"><a href="lots.php">Gestion par lots</a></li>
            <ul>
                <li  style="color:white;"><a href="ajouterlot.php">Ajouter un lot</a></li>
                <li  style="color:white;"><a href="retirerlot.php">Retirer un lot</a></li>
            </ul>
    </ol>
<br>

<h3><center>Articles (pièces)</center></h3>

    <ol>
        <li style="margin-left:10px;color:white;"><a href="ajoutpiece.php">Ajouter des pièces</a></li>
        <li style="margin-left:10px;color:white;"><a href="demontage.php">Fiches de démontage</a></li>
        <li style="margin-left:10px;color:white;"><a href="catalogue.php">Visualiser le catalogue</a></li>
        <li style="margin-left:10px;color:white;"><a href="migrations.php">Visualiser les migrations</a></li>
        <li style="margin-left:10px;color:white;"><a href="importcatalogue.php">Importer un catalogue</a></li>
    </ol>
<br>

<h3><center>Gestion financière</center></h3>

    <ol>
        <li style="margin-left:10px;color:white;"><a href="facturation.php">Outil facturation</a></li>
        <li style="margin-left:10px;color:white;"><a href="facturevehicule.php">Facturation de véhicule</a></li>
        <li style="margin-left:10px;color:white;"><a href="proformas.php">Proformas et documents</a></li>
        <li style="margin-left:10px;color:white;"><a href="bl.php">Bons de livraison</a></li>
        <li style="margin-left:10px;color:white;"><a href="comptabilite.php">Interface comptable</a></li>
        <li style="margin-left:10px;color:white;"><a href="journal.php">Journal de vente</a></li>
        <li style="margin-left:10px;color:white;"><a href="inventaire.php">Inventaire de caisse</a></li>
    </ol>   
<br>

<h3><center>Dépollution</center></h3>

    <ol>
        <li style="margin-left:10px;color:white;"><a href="contenants.php">Gestion des contenants</a></li>
        <li style="margin-left:10px;color:white;"><a href="depollution.php">Dépollution de véhicules</a></li>
        <li style="margin-left:10px;color:white;"><a href="dechets.php">Gestion des déchets</a></li>
        <li style="margin-left:10px;color:white;"><a href="ademe.php">ADEME/SYDEREP</a></li>
    </ol>
<br>

<h3><center>Paramètres</center></h3>

    <ol>
        <li style="margin-left:10px;color:white;"><a href="paramlogiciel.php">Interface et logiciel</a></li>
        <li style="margin-left:10px;color:white;"><a href="intervenants.php">Intervenants et tiers</a></li>
        <li style="margin-left:10px;color:white;"><a href="infospersos.php">Vos informations</a></li>
        <li style="margin-left:10px;color:white;"><a href="deroulantes.php">Listes déroulantes</a></li>
    </ol>
<br>

<h3><center>Statistiques</center></h3>

    <ol>
        <li style="margin-left:10px;color:white;"><a href="stats.php">Vos statistiques</a></li>
    </ol>

<br>
<a href="https://www.vhu2.fr/#equipe"><center>Si vous souhaitez contacter l'équipe VHU2 :</center></a><br>

<a href="mailto:sav@vhu2.fr"><center><img style="width: 100% ;" src="sav.png"/></center></a><br>
<br>

       </div></nav></html>         
        <body>  

<section>

<h1>Fiches de Démontage</h1>

<iframe width="560" height="315" src="https://www.youtube.com/embed/SWQ2ER4jNfk" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

<p>
    Lorsque vous démontez entièrement un véhicule, il est fastidieux de rentrer en stock toutes les pièces récupérées. Vous avez pour cette situation la possibilité d'utiliser des fiches de démontage.<br>
    <br>
    <br>
    Notre partenaire Global PRE propose des fiches de démontage <u>adaptées à chaque véhicule</u> car VHU2 propose par défaut des fiches standards avec une liste d'éléments généraux.<br>
    L'accès aux fiches de Global PRE est soumis à un abonnement auprès d'eux. Si vous souhaiter en savoir plus, contactez notre SAV.<br>
    Vous pourrez retrouver les informations nécessaires à l'utilisation de l'interface Global PRE dans la <a href="globalpre.php">section référente</a>.<br>
    <br>
    <br>
    La première chose à faire est de régler la facon dont seront construites vos références pièces. Pour cela, allez dans <u>Paramétrages</u>, puis dans <u>Site</u>.<br>
</p>

<img style="width: 35% ;" src="contenants1_menu_param.png"/> <img style="width: 35% ;" src="param_site.png">
<br>

<p>
    D'ici, cliquez sur l'onglet <u>Configuration GC</u> et cliquez enfin sur <u>Paramétrer</u> dans l'onglet <u>Aide au référencement des articles</u>.
    <br>
</p>

<img style="width: 80% ;" src="configGC.png">
<br>
<br>

<p>
    Pour paramétrer votre référence, utilisez les flèches pour transférer à droite ou à gauche les critères sélectionnés qui apparaitront sur votre référence et indiquez le nombre de lettres à afficher.<br>
    <br>
    Par exemple, pour la configuration affichée ci-dessous et pour un alternateur de Clio, on obtiendra : "CLIALT" :  3 lettres pour la marque, 3 pour la famille.<br>
</p>

<img style="width: 35% ;" src="referencement_articles.png">
<br>
<br>

<p>
    Voici des exemples de références générées automatiquement avec le numéro de livre de police à la fin pour assurer une tracabilité parfaite.<br>
</p>

<img src="demontage0.6.png" alt="e">
<br>
<br>

<p>
    Une fois le paramétrage effectué, cliquez sur <u>Ok</u> puis sur <u>Enregistrer</u> et revenez au menu principal.<br>
</p> 

<img style="width: 35% ;" src="referencement_ok.png"/> <img style="width: 60% ;" src="referencement_enregistrer.png">
<br>
<br>

<p>
    Vos pièces peuvent être rangées selon plusieurs groupes et sous-groupes qui peuvent apparaître dans la référence, comme illustré ci-dessous:<br>
</p>

<img src="typespiècesvoiture.png" alt="Photo de montagne" /><br>
<img src="typespiècesmoto.png" alt="Photo de montagne" /><br>
<br>

<p>
    Pour accéder aux fiches de démontage, cliquez sur <u>Gestion des articles</u>, puis sur <u>Fiches de démontage</u>.<br>
    <br>
    Cliquez ensuite sur <u>Nouvelle Fiche de démontage</u>.<br>
</p>

<img style="width: 30% ;" src="fichesdémontage1.png"/> <img style="width: 30% ;" src="fichesdémontage2.png"/> <img style="width: 30% ;" src="fichesdémontage3.png">
<br>
<br>

<p>
    Sur cette page, commencez par identifier le véhicule avec le plus d'informations possible. Précisez aussi la date et le nom du démonteur si nécessaire. Vous pouvez imprimer ensuite la fiche en cliquant en bas à gauche.<br>
</p>

<img style="width: 90% ;" src="fichesdémontage4.png">
<br>
<br>

<p>
    Le démonteur pourra cocher les cases correspondantes au fur et à mesure de son démontage.<br>
    Voici les significations des cases (à retrouver en cliquant sur <u>Légende</u>) :<br>
</p>

<img style="width:30% "src="demontage3.png">
<br>
<br>

<p>
    Lorsque le démontage est fini, cochez <u>S</u> pour les pièces à entrer en stock.<br> 
    Cliquez sur <u>Entrées au stock</u> en bas à droite.<br>
    Toutes vos pièces sont alors affublées d'une référence et ajoutées en stock, le véhicule est répertorié comme "Démonté".<br>
</p>

<br>

</section>
</body>
</html>