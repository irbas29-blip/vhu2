 <!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8" />
        <title>Documentation - VHU2</title>
    </head> 

<!DOCTYPE html>
<html>  

<!--


ê
-->
<!--
Liste à améliorer en priorité:
-appli mobile
DARVA
-misiv
-global pre
-team viewer
-site ecommerce
-importer catalogue
-déchets dépollution
-Interface et logiciel 
-->


  




    <head>

        <meta charset="utf-8" />
         <link rel="stylesheet" href="style.css"/>
        <title>Qu'est-il possible de faire avec VHU2 ?</title>

    </head>
   
    <nav id="sommaire">        
    <div class="element_sommaire">
        
      

    <a href="https://www.cardiffvhu2.fr/" id="green"> <img style="width: 100% ;" src="logo vhu2.png"></a>
   
    <a style="display:flex;"href="https://www.youtube.com/playlist?list=PLcUB3Tm73B0EXawxHPw9PEJBR7PLWFJeE"><img src="cam.png" alt="e"><p><div style="font-size:13px;"><br>Retrouvez ici des tutoriels vidéos</div></p></a>

<h3><center>Environnement de VHU2</center></h3>

    <ol>
        <li style="margin-left:10px; color:white;"><a href="index.php">Présentation générale</a></li>
        <li style="margin-left:10px; color:white;"><a href="periph.php">Périphériques </a></li>
            <ul>
                <li  style="color:white;"><a href="douchette.php">Douchette </a></li>
                <li  style="color:white;"><a href="appli.php">Application mobile</a></li>
                <li  style="color:white;"><a href="imprimantes.php">Imprimantes</a></li>
            </ul>
        <li style="margin-left:10px;color:white;"><a href="interfaces.php">Interfaces</a></li>
            <ul>
                <li style="color:white;"><a  href="aaa.php">3A </a></li>
                <li style="color:white;"><a  href="darva.php">DARVA</a></li>
                <li style="color:white;"><a  href="misiv.php">MiSIV-TMS (SIV)</a></li>
                <li style="color:white;"><a  href="globalpre.php">Global PRE</a></li>
                <li style="color:white;"><a  href="teamviewer.php">TeamViewer</a></li>
                <li style="color:white;"><a  href="ecommerce.php">Sites e-commerce </a></li>
            </ul>
        <li style="margin-left:10px;color:white;"><a href="rech.tri.php">Recherche-tri</a></li>
    </ol>
<br>

<h3><center>Dossiers (véhicules)</center></h3>

    <ol>
        <li style="margin-left:10px;color:white;"><a href="ajouterparc.php">Ajouter un véhicule</a></li>
        <li style="margin-left:10px;color:white;"><a href="livrepolice.php">Livre de police</a></li>
        <li style="margin-left:10px;color:white;"><a href="gestionparc.php">Gestion du parc </a></li>
        <li style="margin-left:10px;color:white;"><a href="enlevements.php">Gérer les enlèvements</a></li>
        <li style="margin-left:10px;color:white;"><a href="offres.php">Gérer les appels d'offres</a></li>
        <li style="margin-left:10px;color:white;"><a href="lots.php">Gestion par lots</a></li>
            <ul>
                <li  style="color:white;"><a href="ajouterlot.php">Ajouter un lot</a></li>
                <li  style="color:white;"><a href="retirerlot.php">Retirer un lot</a></li>
            </ul>
    </ol>
<br>

<h3><center>Articles (pièces)</center></h3>

    <ol>
        <li style="margin-left:10px;color:white;"><a href="ajoutpiece.php">Ajouter des pièces</a></li>
        <li style="margin-left:10px;color:white;"><a href="demontage.php">Fiches de démontage</a></li>
        <li style="margin-left:10px;color:white;"><a href="catalogue.php">Visualiser le catalogue</a></li>
        <li style="margin-left:10px;color:white;"><a href="migrations.php">Visualiser les migrations</a></li>
        <li style="margin-left:10px;color:white;"><a href="importcatalogue.php">Importer un catalogue</a></li>
    </ol>
<br>

<h3><center>Gestion financière</center></h3>

    <ol>
        <li style="margin-left:10px;color:white;"><a href="facturation.php">Outil facturation</a></li>
        <li style="margin-left:10px;color:white;"><a href="facturevehicule.php">Facturation de véhicule</a></li>
        <li style="margin-left:10px;color:white;"><a href="proformas.php">Proformas et documents</a></li>
        <li style="margin-left:10px;color:white;"><a href="bl.php">Bons de livraison</a></li>
        <li style="margin-left:10px;color:white;"><a href="comptabilite.php">Interface comptable</a></li>
        <li style="margin-left:10px;color:white;"><a href="journal.php">Journal de vente</a></li>
        <li style="margin-left:10px;color:white;"><a href="inventaire.php">Inventaire de caisse</a></li>
    </ol>   
<br>

<h3><center>Dépollution</center></h3>

    <ol>
        <li style="margin-left:10px;color:white;"><a href="contenants.php">Gestion des contenants</a></li>
        <li style="margin-left:10px;color:white;"><a href="depollution.php">Dépollution de véhicules</a></li>
        <li style="margin-left:10px;color:white;"><a href="dechets.php">Gestion des déchets</a></li>
        <li style="margin-left:10px;color:white;"><a href="ademe.php">ADEME/SYDEREP</a></li>
    </ol>
<br>

<h3><center>Paramètres</center></h3>

    <ol>
        <li style="margin-left:10px;color:white;"><a href="paramlogiciel.php">Interface et logiciel</a></li>
        <li style="margin-left:10px;color:white;"><a href="intervenants.php">Intervenants et tiers</a></li>
        <li style="margin-left:10px;color:white;"><a href="infospersos.php">Vos informations</a></li>
        <li style="margin-left:10px;color:white;"><a href="deroulantes.php">Listes déroulantes</a></li>
    </ol>
<br>

<h3><center>Statistiques</center></h3>

    <ol>
        <li style="margin-left:10px;color:white;"><a href="stats.php">Vos statistiques</a></li>
    </ol>

<br>
<a href="https://www.vhu2.fr/#equipe"><center>Si vous souhaitez contacter l'équipe VHU2 :</center></a><br>

<a href="mailto:sav@vhu2.fr"><center><img style="width: 100% ;" src="sav.png"/></center></a><br>
<br>

       </div></nav></html>       <body>  

    <section>

<h1>Votre Site E-Commerce</h1>
   
  <h2>Export de Véhicules d'occasions ou accidentés</h2>

    <p>
      VHU2 vous offre la possibilité de publier des annonces de vente de VA/VO ainsi que de pièces de réemplois, directement depuis le logiciel.
 Plusieurs canaux peuvent être utilisés tel que votre site internet (qu'il faudra paramétrer). Vous pouvez également publier ces annonces depuis VHU2 via des plateformes comme Ebay, Reparcar, voiturepourpièces.fr ainsi que global PRE.
 
.<br>
      <br>
      Dans le menu principal, cliquez sur <u>outils et e-commerce</u> puis sur <u>Multidiffusion e-commerce</u>. <br>
    </p>

    <img src="Recherche pièces. ROUGE png.png" > 
    <br>
    <br>


    <p>
      Les critères de recherche, en haut à gauche, permettent de distinguer les véhicules des pièces détachées.
Ici nous nous intéressons uniquement aux véhicules.
Il est possible de chercher un véhicule déjà présent sur le logiciel via son numéro de livre de police, sa plaque d’immatriculation, ou via des critères tels que la marque, le modèle etc…
Il suffit ensuite de cocher la voiture que vous souhaitez mettre en vente, puis le canal de diffusion à travers le(s)quel(s) vous souhaitez le vendre (ici votre site Internet ou voiturepourpièces.fr).
 Une fois ces canaux sélectionnés, cliquez sur le bouton vert en bas à droite « Mettre à jour les annonces » pour publier votre véhicule sur le site de votre choix.

    </p>

    <img src="VO VA Rouge.png">
    <br>
    <br>

    <p>
      Vous pouvez rechercher les pièces disponibles sur un véhicule donné. Pour cela, il vous faut sélectionner le véhicule choisi via les critères d’information (ici livre de police).
Lorsque vous sélectionnez un véhicule dans l’onglet « pièces », toutes les PRE concernant ce véhicule-là, que vous aviez sélectionnées via vos fiches de démontages apparaissent à l’écran.
Il vous suffit donc de sélectionner les pièces que vous souhaitez vendre, puis cocher le canal de vente par lequel vous souhaitez passer. Cliquez sur le bouton vert en bas à droite de l’écran « Mettre à jour les annonces » pour publier les pièces que vous souhaitez mettre en vente.

    </p>

    <img src="E commerce; selection canaux diffusion ROUGE .png"> 
    <br>
    <br>

    <p>
     Il est également possible de consulter vos PRE disponibles ainsi que les canaux de ventes sur lesquels ils sont présents (ou pas), via les critères de recherche de pièces.
Il suffit pour cela d’utiliser les listes déroulantes et de sélectionner une famille ou un type de pièce, une marque etc…
Vous pouvez ensuite choisir de mettre en vente une pièce (ou de la retirer) en cochant ou non les différents canaux de diffusion existant.
Attention, il faut impérativement mettre à jour les annonces après chaque modification.

  

    
    <br>
    <br>

    
    </p>
    <br>
    <br>

  <h2>Création du site</h2>

    <p>
      Nous sommes concients qu'il est peu probable que vous ayez déjà une page WooCommerce ou Prestashop. Nous vous offrons donc la possibilité de vous la créer.<br>
      <br>
      Nous avons en effet dans nos rangs des webdesigners qui sont prêts à vous accompagner. Contactez nous pour obtenir des détails ainsi que des tarifs.<br>
      Il est certain que cette page peut grandement augmenter votre visibilité et par conséquent votre chiffre d'affaires.<br>
    </p>
    <br>

</section>
</body>
</html>